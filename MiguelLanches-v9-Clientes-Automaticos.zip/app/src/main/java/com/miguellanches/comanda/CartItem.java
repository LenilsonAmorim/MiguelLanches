package com.miguellanches.comanda;

import java.util.ArrayList;
import java.util.List;

public class CartItem {
    public Product product;
    public int quantity;
    public String note;
    public ArrayList<String> extras;

    public CartItem(Product product, int quantity, String note, List<String> extras) {
        this.product = product;
        this.quantity = quantity;
        this.note = note == null ? "" : note;
        this.extras = new ArrayList<>();
        if (extras != null) this.extras.addAll(extras);
    }

    public boolean sameConfiguration(Product p, String n, List<String> ex) {
        if (p == null || product == null) return false;
        if (!product.category.equals(p.category) || !product.name.equals(p.name) || product.price != p.price) return false;
        String a = n == null ? "" : n.trim();
        if (!note.equals(a)) return false;
        ArrayList<String> b = new ArrayList<>();
        if (ex != null) b.addAll(ex);
        return extras.equals(b);
    }
}
