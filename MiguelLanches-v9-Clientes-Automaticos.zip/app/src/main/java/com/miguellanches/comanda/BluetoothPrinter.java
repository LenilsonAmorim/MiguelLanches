package com.miguellanches.comanda;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class BluetoothPrinter {
    private static final int REQ_BT=77;
    private static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    public interface Callback { void done(boolean ok,String msg); }

    public static void print(Activity a,String text,Callback cb){
        if(Build.VERSION.SDK_INT>=31 && a.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){
            a.requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT); Toast.makeText(a,"Permita o Bluetooth e toque em IMPRIMIR novamente.",Toast.LENGTH_LONG).show(); return;
        }
        BluetoothAdapter adapter=BluetoothAdapter.getDefaultAdapter();
        if(adapter==null){cb.done(false,"Este aparelho não possui Bluetooth.");return;}
        if(!adapter.isEnabled()){cb.done(false,"Ative o Bluetooth primeiro.");return;}
        Set<BluetoothDevice> bonded=adapter.getBondedDevices();
        if(bonded==null||bonded.isEmpty()){cb.done(false,"Nenhuma impressora Bluetooth pareada. Pareie a impressora nas configurações do Android.");return;}
        ArrayList<BluetoothDevice> list=new ArrayList<>(bonded); String[] names=new String[list.size()];
        for(int i=0;i<list.size();i++){BluetoothDevice d=list.get(i); names[i]=(d.getName()==null?"Dispositivo":d.getName())+"\n"+d.getAddress();}
        new AlertDialog.Builder(a).setTitle("Escolha a impressora 58mm").setItems(names,(d,which)->connect(a,list.get(which),text,cb)).setNegativeButton("Cancelar",null).show();
    }
    private static void connect(Activity a,BluetoothDevice device,String text,Callback cb){
        new Thread(()->{
            BluetoothSocket socket=null;
            try{
                BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                socket=device.createRfcommSocketToServiceRecord(SPP); socket.connect();
                OutputStream out=socket.getOutputStream();
                out.write(new byte[]{0x1B,0x40});
                out.write(new byte[]{0x1B,0x61,0x00});
                out.write(text.getBytes(Charset.forName("CP850")));
                out.write(new byte[]{0x0A,0x0A,0x0A});
                out.write(new byte[]{0x1D,0x56,0x00});
                out.flush(); out.close(); socket.close();
                a.runOnUiThread(()->cb.done(true,"Comanda enviada para "+(device.getName()==null?"a impressora":device.getName())));
            }catch(Exception e){try{if(socket!=null)socket.close();}catch(Exception ignored){} a.runOnUiThread(()->cb.done(false,"Não foi possível imprimir. Verifique se a impressora está pareada e ligada."));}
        }).start();
    }
}
