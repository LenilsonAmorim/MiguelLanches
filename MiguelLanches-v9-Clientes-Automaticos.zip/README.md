# Miguel Lanches v9

Inclui:
- clientes salvos automaticamente ao imprimir;
- busca por nome;
- tratamento de nomes iguais com números diferentes como clientes distintos;
- preenchimento de WhatsApp, endereço e referência ao selecionar cliente;
- tela de clientes para consultar/excluir cadastros;
- histórico e WhatsApp da v8 mantidos.
