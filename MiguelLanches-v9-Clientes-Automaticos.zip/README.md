# Miguel Lanches v9

Inclui cadastro automático de clientes e, após uma impressão concluída,
abre o WhatsApp do cliente com a mensagem de recebimento do pedido e
prazo estimado de 40 a 90 minutos.

O WhatsApp abre com a mensagem pronta para envio; o atendente toca em
Enviar. Se o telefone não estiver preenchido, a impressão continua
normalmente e o WhatsApp não é aberto.
