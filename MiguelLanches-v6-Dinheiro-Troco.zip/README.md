# Miguel Lanches v5

- Categorias na ordem: Sanduíches, Pizzas, Pastéis, Porções, Açaí, Churrasco, Bebidas.
- Dois produtos iniciais por categoria.
- Açaí com limite configurável de ingredientes (padrão: 3).
- Bebidas seguem o padrão de seleção de produtos.
- Ingredientes e preços editáveis no próprio app.
