package br.com.miguellanches.comanda

import android.Manifest
import android.app.AlertDialog
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class Category(var id: Long, var name: String)
data class Product(var id: Long, var categoryId: Long, var name: String, var price: Double, var active: Boolean = true)
data class Addon(var id: Long, var name: String, var price: Double, var active: Boolean = true)
data class CartItem(var product: Product, var qty: Int, val addons: MutableList<Addon> = mutableListOf(), var note: String = "") {
    fun unitTotal(): Double = product.price + addons.sumOf { it.price }
    fun total(): Double = unitTotal() * qty
}

class MainActivity : Activity() {

    private val blue = Color.rgb(34, 70, 170)
    private val blueDark = Color.rgb(18, 39, 92)
    private val bg = Color.rgb(245, 247, 251)
    private val red = Color.rgb(198, 43, 51)

    private val categories = mutableListOf<Category>()
    private val products = mutableListOf<Product>()
    private val addons = mutableListOf<Addon>()
    private val cart = mutableListOf<CartItem>()
    private var nextId = 1L
    private var nextOrder = 1

    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        seed()
        showHome()
    }

    private fun seed() {
        if (categories.isNotEmpty()) return
        categories += Category(nextId++, "Hambúrgueres")
        categories += Category(nextId++, "Pizzas")
        categories += Category(nextId++, "Pastéis")
        categories += Category(nextId++, "Bebidas")
        categories += Category(nextId++, "Porções")
        categories += Category(nextId++, "Açaí")
        products += Product(nextId++, categories[0].id, "Hambúrguer da Casa", 20.0)
        products += Product(nextId++, categories[1].id, "Pizza Mussarela", 28.0)
        products += Product(nextId++, categories[2].id, "Pastel de Frango", 9.0)
        products += Product(nextId++, categories[3].id, "Refrigerante Lata", 6.0)
        addons += Addon(nextId++, "Bacon", 4.0)
        addons += Addon(nextId++, "Catupiry", 4.0)
    }

    private fun makeRoot(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setBackgroundColor(bg)
        return r
    }

    private fun bar(title: String, back: Boolean = false, right: String? = null, click: (() -> Unit)? = null): LinearLayout {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.HORIZONTAL
        b.gravity = Gravity.CENTER_VERTICAL
        b.setPadding(14, 10, 10, 10)
        b.setBackgroundColor(blueDark)

        if (back) {
            val v = TextView(this)
            v.text = "‹"
            v.textSize = 34f
            v.setTextColor(Color.WHITE)
            v.gravity = Gravity.CENTER
            v.setOnClickListener { showHome() }
            b.addView(v, LinearLayout.LayoutParams(dp(44), dp(52)))
        }

        val t = TextView(this)
        t.text = title
        t.textSize = 21f
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER_VERTICAL
        b.addView(t, LinearLayout.LayoutParams(0, dp(52), 1f))

        if (right != null) {
            val a = TextView(this)
            a.text = right
            a.textSize = 14f
            a.setTextColor(Color.WHITE)
            a.gravity = Gravity.CENTER
            a.setPadding(10, 0, 10, 0)
            a.setOnClickListener { click?.invoke() }
            b.addView(a, LinearLayout.LayoutParams(dp(110), dp(52)))
        }
        return b
    }

    private fun showHome() {
        root = makeRoot()
        root.addView(bar("MIGUEL LANCHES"))

        val gridScroll = ScrollView(this)
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        grid.setPadding(14, 14, 14, 110)

        addAction(grid, "➕ NOVA COMANDA") { showCategories() }
        addAction(grid, "🧾 COMANDAS ABERTAS") { showCurrentCart() }
        addAction(grid, "📦 CADASTRO DE PRODUTOS") { showProductsAdmin() }
        addAction(grid, "📂 CATEGORIAS") { showCategoriesAdmin() }
        addAction(grid, "➕ ADICIONAIS") { showAddonsAdmin() }
        addAction(grid, "🖨️ IMPRESSORA") { printerInfo() }

        gridScroll.addView(grid)
        root.addView(gridScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun addAction(container: LinearLayout, text: String, click: () -> Unit) {
        val b = Button(this)
        b.text = text
        b.textSize = 17f
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        b.setOnClickListener { click() }
        val lp = LinearLayout.LayoutParams(-1, dp(64))
        lp.setMargins(0, 7, 0, 7)
        container.addView(b, lp)
    }

    private fun showCategories() {
        root = makeRoot()
        root.addView(bar("NOVA COMANDA", true, "VER COMANDA") { showCurrentCart() })
        val scroll = ScrollView(this)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(14, 14, 14, 100)
        categories.filter { it.name.isNotBlank() }.forEach { c ->
            addAction(list, c.name) { showProducts(c) }
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = Button(this)
        bottom.text = "COMANDA • ${cart.sumOf { it.qty }} ITENS • R$ %.2f".format(Locale("pt","BR"), total())
        bottom.setOnClickListener { showCurrentCart() }
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(60)))
        setContentView(root)
    }

    private fun showProducts(category: Category) {
        root = makeRoot()
        root.addView(bar(category.name, true, "COMANDA") { showCurrentCart() })

        val scroll = ScrollView(this)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(12, 12, 12, 100)

        products.filter { it.categoryId == category.id && it.active }.forEach { p ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(15, 13, 15, 13)
            row.setBackgroundColor(Color.WHITE)
            val title = TextView(this)
            title.text = p.name
            title.textSize = 17f
            title.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            row.addView(title)
            val price = TextView(this)
            price.text = "R$ %.2f".format(Locale("pt","BR"), p.price)
            price.textSize = 16f
            price.setTextColor(red)
            row.addView(price)
            row.setOnClickListener { configureProduct(p) }
            list.addView(row, LinearLayout.LayoutParams(-1, dp(74)).apply { setMargins(0,0,0,7) })
        }

        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val b = Button(this)
        b.text = "COMANDA • ${cart.sumOf { it.qty }} ITENS"
        b.setOnClickListener { showCurrentCart() }
        root.addView(b, LinearLayout.LayoutParams(-1, dp(58)))
        setContentView(root)
    }

    private fun configureProduct(p: Product) {
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(20, 10, 20, 5)

        val q = EditText(this)
        q.hint = "Quantidade"
        q.inputType = InputType.TYPE_CLASS_NUMBER
        q.setText("1")
        layout.addView(q)

        val note = EditText(this)
        note.hint = "Observação do item"
        layout.addView(note)

        val checks = mutableListOf<CheckBox>()
        addons.filter { it.active }.forEach { a ->
            val cb = CheckBox(this)
            cb.text = "${a.name} (+R$ %.2f)".format(Locale("pt","BR"), a.price)
            checks += cb
            layout.addView(cb)
        }

        AlertDialog.Builder(this)
            .setTitle(p.name)
            .setView(layout)
            .setPositiveButton("ADICIONAR") { _, _ ->
                val qty = q.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1
                val selected = checks.mapIndexedNotNull { i, cb -> if (cb.isChecked) addons.filter { it.active }.getOrNull(i) else null }
                cart += CartItem(p, qty, selected.toMutableList(), note.text.toString())
                Toast.makeText(this, "Produto adicionado", Toast.LENGTH_SHORT).show()
                showCategories()
            }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private fun showCurrentCart() {
        root = makeRoot()
        root.addView(bar("COMANDA", true, "LIMPAR") { cart.clear(); showCurrentCart() })

        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        info.setPadding(14, 10, 14, 0)

        val client = EditText(this)
        client.hint = "Nome do cliente"
        val address = EditText(this)
        address.hint = "Endereço"
        val obs = EditText(this)
        obs.hint = "Observações do pedido"
        info.addView(client)
        info.addView(address)
        root.addView(info)

        val scroll = ScrollView(this)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(12, 8, 12, 8)

        if (cart.isEmpty()) {
            val empty = TextView(this)
            empty.text = "Nenhum produto na comanda."
            empty.textSize = 18f
            empty.setPadding(10, 25, 10, 25)
            list.addView(empty)
        } else {
            cart.forEachIndexed { index, item ->
                val row = LinearLayout(this)
                row.orientation = LinearLayout.VERTICAL
                row.setPadding(14, 10, 14, 10)
                row.setBackgroundColor(Color.WHITE)

                val line = TextView(this)
                line.text = "${item.qty}x ${item.product.name}  •  R$ %.2f".format(Locale("pt","BR"), item.total())
                line.textSize = 16f
                line.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                row.addView(line)

                if (item.addons.isNotEmpty()) {
                    val ad = TextView(this)
                    ad.text = "Adicionais: " + item.addons.joinToString(", ") { it.name }
                    ad.textSize = 13f
                    ad.setTextColor(Color.DKGRAY)
                    row.addView(ad)
                }
                if (item.note.isNotBlank()) {
                    val no = TextView(this)
                    no.text = "Obs.: ${item.note}"
                    no.textSize = 13f
                    no.setTextColor(Color.DKGRAY)
                    row.addView(no)
                }

                row.setOnClickListener { cart.removeAt(index); showCurrentCart() }
                list.addView(row, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0,0,0,7) })
            }
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val total = TextView(this)
        total.text = "TOTAL: R$ %.2f".format(Locale("pt","BR"), total())
        total.textSize = 22f
        total.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        total.setTextColor(blue)
        total.gravity = Gravity.END
        total.setPadding(12, 5, 12, 10)
        root.addView(total)

        val print = Button(this)
        print.text = "🖨️ FINALIZAR E IMPRIMIR"
        print.setOnClickListener {
            printerInfo()
        }
        root.addView(print, LinearLayout.LayoutParams(-1, dp(62)))

        setContentView(root)
    }

    private fun showCategoriesAdmin() {
        root = makeRoot()
        root.addView(bar("CATEGORIAS", true))
        val scroll = ScrollView(this)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(12, 12, 12, 90)

        val add = Button(this)
        add.text = "➕ NOVA CATEGORIA"
        add.setOnClickListener { askCategory() }
        list.addView(add, LinearLayout.LayoutParams(-1, dp(58)))

        categories.forEach { c ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(12, 6, 6, 6)
            val tv = TextView(this)
            tv.text = c.name
            tv.textSize = 17f
            row.addView(tv, LinearLayout.LayoutParams(0, dp(58), 1f))
            val edit = Button(this)
            edit.text = "EDITAR"
            edit.setOnClickListener { askCategory(c) }
            row.addView(edit, LinearLayout.LayoutParams(dp(90), dp(55)))
            val del = Button(this)
            del.text = "EXCLUIR"
            del.setOnClickListener {
                categories.remove(c)
                products.removeAll { it.categoryId == c.id }
                showCategoriesAdmin()
            }
            row.addView(del, LinearLayout.LayoutParams(dp(90), dp(55)))
            list.addView(row)
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun askCategory(existing: Category? = null) {
        val e = EditText(this)
        e.setText(existing?.name ?: "")
        e.hint = "Nome da categoria"
        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Nova categoria" else "Editar categoria")
            .setView(e)
            .setPositiveButton("SALVAR") { _, _ ->
                val n = e.text.toString().trim()
                if (n.isNotBlank()) {
                    if (existing == null) categories += Category(nextId++, n)
                    else existing.name = n
                }
                showCategoriesAdmin()
            }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private fun showProductsAdmin() {
        root = makeRoot()
        root.addView(bar("PRODUTOS", true))
        val scroll = ScrollView(this)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(12, 12, 12, 100)

        val add = Button(this)
        add.text = "➕ NOVO PRODUTO"
        add.setOnClickListener { askProduct() }
        list.addView(add, LinearLayout.LayoutParams(-1, dp(58)))

        products.forEach { p ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(14, 8, 14, 8)
            val tv = TextView(this)
            val cat = categories.firstOrNull { it.id == p.categoryId }?.name ?: "Sem categoria"
            tv.text = "${p.name}\n${cat} • R$ %.2f".format(Locale("pt","BR"), p.price)
            tv.textSize = 16f
            row.addView(tv)
            val actions = LinearLayout(this)
            val edit = Button(this)
            edit.text = "EDITAR"
            edit.setOnClickListener { askProduct(p) }
            val del = Button(this)
            del.text = "EXCLUIR"
            del.setOnClickListener { products.remove(p); showProductsAdmin() }
            actions.addView(edit, LinearLayout.LayoutParams(0, dp(50), 1f))
            actions.addView(del, LinearLayout.LayoutParams(0, dp(50), 1f))
            row.addView(actions)
            list.addView(row, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0,0,0,8) })
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun askProduct(existing: Product? = null) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(18, 5, 18, 0)

        val name = EditText(this)
        name.hint = "Nome do produto"
        name.setText(existing?.name ?: "")
        box.addView(name)

        val price = EditText(this)
        price.hint = "Preço"
        price.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        price.setText(existing?.price?.toString() ?: "")
        box.addView(price)

        val catSpinner = Spinner(this)
        val names = categories.map { it.name }
        catSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        existing?.let {
            val index = categories.indexOfFirst { c -> c.id == it.categoryId }
            if (index >= 0) catSpinner.setSelection(index)
        }
        box.addView(catSpinner)

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Novo produto" else "Editar produto")
            .setView(box)
            .setPositiveButton("SALVAR") { _, _ ->
                val n = name.text.toString().trim()
                val pr = price.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0
                val idx = catSpinner.selectedItemPosition.coerceIn(0, categories.lastIndex)
                if (n.isNotBlank() && categories.isNotEmpty()) {
                    if (existing == null) {
                        products += Product(nextId++, categories[idx].id, n, pr)
                    } else {
                        existing.name = n
                        existing.price = pr
                        existing.categoryId = categories[idx].id
                    }
                }
                showProductsAdmin()
            }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private fun showAddonsAdmin() {
        root = makeRoot()
        root.addView(bar("ADICIONAIS", true))
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(12, 12, 12, 90)

        val add = Button(this)
        add.text = "➕ NOVO ADICIONAL"
        add.setOnClickListener { askAddon() }
        list.addView(add, LinearLayout.LayoutParams(-1, dp(58)))

        addons.forEach { a ->
            val row = TextView(this)
            row.text = "${a.name} • R$ %.2f".format(Locale("pt","BR"), a.price)
            row.textSize = 17f
            row.setPadding(14, 15, 14, 15)
            row.setBackgroundColor(Color.WHITE)
            row.setOnClickListener { askAddon(a) }
            list.addView(row, LinearLayout.LayoutParams(-1, dp(62)).apply { setMargins(0,0,0,7) })
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun askAddon(existing: Addon? = null) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(18, 5, 18, 0)

        val name = EditText(this)
        name.hint = "Nome"
        name.setText(existing?.name ?: "")
        box.addView(name)

        val price = EditText(this)
        price.hint = "Preço"
        price.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        price.setText(existing?.price?.toString() ?: "")
        box.addView(price)

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Novo adicional" else "Editar adicional")
            .setView(box)
            .setPositiveButton("SALVAR") { _, _ ->
                val n = name.text.toString().trim()
                val pr = price.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0
                if (n.isNotBlank()) {
                    if (existing == null) addons += Addon(nextId++, n, pr)
                    else {
                        existing.name = n
                        existing.price = pr
                    }
                }
                showAddonsAdmin()
            }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private fun printerInfo() {
        if (android.os.Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 100)
            return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            AlertDialog.Builder(this).setTitle("Impressora").setMessage("Bluetooth não disponível.").setPositiveButton("OK", null).show()
            return
        }
        val devices = try { adapter.bondedDevices.toList() } catch (_: Exception) { emptyList<BluetoothDevice>() }
        if (devices.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Impressora").setMessage("Pareie primeiro sua impressora térmica no Bluetooth do Android.").setPositiveButton("OK", null).show()
            return
        }
        val names = devices.map { "${it.name ?: "Sem nome"}\n${it.address}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Escolha a impressora")
            .setItems(names) { _, which -> printReceipt(devices[which]) }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private fun printReceipt(device: BluetoothDevice) {
        val text = receiptText()
        Thread {
            try {
                val socket = device.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
                socket.connect()
                val out: OutputStream = socket.outputStream
                out.write(byteArrayOf(0x1B, 0x40))
                out.write(text.toByteArray(Charsets.ISO_8859_1))
                out.write(byteArrayOf(0x0A,0x0A,0x0A,0x1D,0x56,0x00))
                out.flush()
                out.close()
                socket.close()
                runOnUiThread {
                    Toast.makeText(this, "Pedido impresso.", Toast.LENGTH_LONG).show()
                    cart.clear()
                    nextOrder++
                    showHome()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Falha ao imprimir: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun receiptText(): String {
        val sb = StringBuilder()
        sb.appendLine("================================")
        sb.appendLine(center("MIGUEL LANCHES",32))
        sb.appendLine("================================")
        sb.appendLine("PEDIDO: #${String.format("%03d", nextOrder)}")
        sb.appendLine(SimpleDateFormat("dd/MM/yyyy - HH:mm", Locale("pt","BR")).format(Date()))
        sb.appendLine()
        cart.forEach {
            sb.appendLine(String.format(Locale.US, "%02d  %-19s R$ %5.2f", it.qty, it.product.name.take(19), it.total()))
            if (it.addons.isNotEmpty()) sb.appendLine("     + " + it.addons.joinToString(", ") { a -> a.name })
            if (it.note.isNotBlank()) sb.appendLine("     Obs: ${it.note}")
        }
        sb.appendLine("--------------------------------")
        sb.appendLine(String.format(Locale.US, "TOTAL:                  R$ %.2f", total()))
        sb.appendLine("================================")
        sb.appendLine(center("Obrigado!",32))
        return sb.toString()
    }

    private fun total() = cart.sumOf { it.total() }

    private fun center(text: String, width: Int): String {
        val t = text.take(width)
        return " ".repeat(((width - t.length).coerceAtLeast(0))/2) + t
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
