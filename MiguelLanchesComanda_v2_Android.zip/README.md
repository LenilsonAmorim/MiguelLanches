# Miguel Lanches Comanda v2

Aplicativo Android nativo próprio, inspirado no fluxo de uma comanda eletrônica:
- nova comanda
- categorias
- produtos
- adicionais
- carrinho/comanda
- cliente/endereço/observações
- cadastro/edição/exclusão de categorias, produtos e adicionais
- impressão ESC/POS Bluetooth em impressoras pareadas

O cardápio começa com alguns exemplos e pode ser cadastrado/editado dentro do próprio aplicativo.
