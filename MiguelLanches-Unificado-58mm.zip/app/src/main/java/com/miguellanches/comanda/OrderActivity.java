package com.miguellanches.comanda;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class OrderActivity extends Activity {
    public static ArrayList<Product> cart=new ArrayList<>();
    LinearLayout list; TextView total; EditText customer,address,ref,obs,delivery; Spinner payment,status; int purple=Color.rgb(91,45,179),dark=Color.rgb(45,24,91),bg=Color.rgb(247,245,251);
    int dp(float v){return(int)(v*getResources().getDisplayMetrics().density+0.5f);}
    TextView tv(String s,float z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);t.setTypeface(Typeface.DEFAULT,b?Typeface.BOLD:Typeface.NORMAL);return t;}
    GradientDrawable shape(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(shape(purple,14));return b;}
    @Override public void onCreate(Bundle b){super.onCreate(b);build();}
    TextView label(String s){TextView t=tv(s,12,Color.DKGRAY,true);t.setPadding(dp(2),dp(7),0,0);return t;}
    void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
        TextView bar=tv("‹  COMANDA",20,Color.WHITE,true);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(10),0,0,0);bar.setBackgroundColor(purple);bar.setOnClickListener(v->finish());root.addView(bar,new LinearLayout.LayoutParams(-1,dp(58)));
        ScrollView sv=new ScrollView(this);LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(12),dp(10),dp(12),dp(115));
        TextView title=tv("🧾  RESUMO DO PEDIDO",21,Color.BLACK,true);title.setGravity(Gravity.CENTER);content.addView(title,new LinearLayout.LayoutParams(-1,dp(42)));
        customer=field("Cliente");address=field("Endereço");ref=field("Referência");obs=field("Observações"); delivery=field("Taxa de entrega (R$)");
        addField(content,"CLIENTE",customer);addField(content,"ENDEREÇO",address);addField(content,"REFERÊNCIA",ref);addField(content,"OBSERVAÇÕES",obs);addField(content,"TAXA DE ENTREGA",delivery); delivery.setInputType(2|8192);
        LinearLayout selects=new LinearLayout(this);selects.setPadding(0,dp(4),0,dp(4)); payment=new Spinner(this);status=new Spinner(this); setSpinner(payment,new String[]{"PIX","DINHEIRO","CARTÃO","PENDENTE"}); setSpinner(status,new String[]{"PAGO","PENDENTE"}); selects.addView(payment,new LinearLayout.LayoutParams(0,dp(52),1)); selects.addView(status,new LinearLayout.LayoutParams(0,dp(52),1)); content.addView(selects);
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        total=tv("",19,purple,true);total.setGravity(Gravity.RIGHT);content.addView(total,new LinearLayout.LayoutParams(-1,dp(55)));
        sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bottom=new LinearLayout(this);bottom.setPadding(dp(7),dp(6),dp(7),dp(6));bottom.setBackgroundColor(Color.WHITE);
        Button clear=button("LIMPAR"),share=button("COMPARTILHAR"),print=button("🖨  IMPRIMIR");bottom.addView(clear,new LinearLayout.LayoutParams(0,dp(52),1));bottom.addView(share,new LinearLayout.LayoutParams(0,dp(52),1));bottom.addView(print,new LinearLayout.LayoutParams(0,dp(52),1));
        clear.setOnClickListener(v->{cart.clear();render();});share.setOnClickListener(v->{Intent s=new Intent(Intent.ACTION_SEND);s.setType("text/plain");s.putExtra(Intent.EXTRA_TEXT,receipt());startActivity(Intent.createChooser(s,"Compartilhar comanda"));});print.setOnClickListener(v->doPrint());root.addView(bottom);setContentView(root);render();
    }
    EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(false);e.setTextSize(14);e.setPadding(dp(10),0,dp(10),0);e.setBackground(shape(Color.WHITE,12));return e;}
    void addField(LinearLayout c,String label,EditText e){c.addView(label(label));c.addView(e,new LinearLayout.LayoutParams(-1,dp(48)));}
    void setSpinner(Spinner s,String[] vals){ArrayAdapter<String>a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,vals);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(a);}
    void render(){list.removeAllViews();double sub=0;for(Product p:cart){sub+=p.price;LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),0,dp(8),0);row.setBackground(shape(Color.WHITE,10));TextView n=tv("1x  "+p.name,14,Color.DKGRAY,true);TextView pr=tv(String.format(Locale.US,"R$ %.2f",p.price).replace('.',','),14,purple,true);pr.setGravity(Gravity.CENTER);row.addView(n,new LinearLayout.LayoutParams(0,dp(50),1));row.addView(pr,new LinearLayout.LayoutParams(dp(95),dp(50)));list.addView(row,new LinearLayout.LayoutParams(-1,dp(52)));Space sp=new Space(this);list.addView(sp,new LinearLayout.LayoutParams(1,dp(5)));}double fee=num(delivery);total.setText(String.format(Locale.US,"SUBTOTAL: R$ %.2f\nTOTAL: R$ %.2f",sub,sub+fee).replace('.',','));}
    double num(EditText e){try{return Double.parseDouble(e.getText().toString().replace(",","."));}catch(Exception x){return 0;}}
    String fit(String s){s=s==null?"":s.replace("\r","").replace("\n"," "); if(s.length()>32)return s.substring(0,32);StringBuilder b=new StringBuilder(s);while(b.length()<32)b.append(' ');return b.toString();}
    String right(String label,double value){String val=String.format(Locale.US,"R$ %.2f",value).replace('.',',');int spaces=32-label.length()-val.length();if(spaces<1)spaces=1;return fit(label+repeat(' ',spaces)+val);}
    String repeat(char c,int n){StringBuilder b=new StringBuilder();for(int i=0;i<n;i++)b.append(c);return b.toString();}
    String itemLine(Product p){String q="1x";String name=p.name==null?"":p.name.toUpperCase(Locale.ROOT);if(name.length()>19)name=name.substring(0,19);String val=String.format(Locale.US,"%.2f",p.price).replace('.',',');return fit(q+"  "+name+repeat(' ',Math.max(1,32-4-name.length()-val.length()))+val+"  ");}
    String receipt(){
        Calendar now=Calendar.getInstance();String date=new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(now.getTime());String time=new SimpleDateFormat("HH:mm",Locale.getDefault()).format(now.getTime());int no=getPreferences(0).getInt("order",1);double sub=0;for(Product p:cart)sub+=p.price;double fee=num(delivery);double totalV=sub+fee;
        StringBuilder s=new StringBuilder();s.append("================================\n");s.append(fit("         MIGUEL LANCHES         ")+"\n");s.append(fit("   Hamburgueria e Pizzaria")+"\n");s.append("================================\n");s.append(fit("Data: "+date+"    Hora: "+time)+"\n");s.append(fit("Pedido: #"+String.format(Locale.US,"%03d",no))+"\n");s.append("--------------------------------\n");s.append("QTD ITEM                 VALOR  \n");s.append("--------------------------------\n");for(Product p:cart)s.append(itemLine(p)).append("\n");s.append("--------------------------------\n");s.append(right("SUBTOTAL:",sub)+"\n");s.append(right("TAXA DE ENTREGA:",fee)+"\n");s.append("--------------------------------\n");s.append(right("TOTAL:",totalV)+"\n");s.append("--------------------------------\n");s.append(fit("FORMA DE PAGAMENTO: "+payment.getSelectedItem().toString())+"\n");s.append(fit("STATUS: "+status.getSelectedItem().toString())+"\n");s.append("--------------------------------\n");s.append(fit("CLIENTE: "+customer.getText().toString())+"\n");s.append(fit("ENDERECO: "+address.getText().toString())+"\n");s.append(fit("REF: "+ref.getText().toString())+"\n");s.append(fit("OBS: "+obs.getText().toString())+"\n");s.append("================================\n");s.append(fit("    Obrigado pela preferencia!")+"\n");s.append("================================\n");return s.toString();
    }
    void doPrint(){if(cart.isEmpty()){Toast.makeText(this,"Adicione pelo menos um produto.",Toast.LENGTH_SHORT).show();return;}BluetoothPrinter.print(this,receipt(),(ok,msg)->{Toast.makeText(this,msg,Toast.LENGTH_LONG).show();if(ok){int n=getPreferences(0).getInt("order",1);getPreferences(0).edit().putInt("order",n+1).apply();}});}
}
