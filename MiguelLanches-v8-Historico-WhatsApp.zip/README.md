Miguel Lanches v7 - Pagamento em dinheiro

Inclui:
- Seleção de DINHEIRO na comanda abre uma tela de pagamento.
- Mostra o total a pagar.
- Campo para valor recebido.
- Calcula troco automaticamente.
- Não permite confirmar valor menor que o total.
- Valor recebido e troco aparecem na impressão de 32 caracteres.
- Mantém categorias, adicionais e demais funções da v6.
