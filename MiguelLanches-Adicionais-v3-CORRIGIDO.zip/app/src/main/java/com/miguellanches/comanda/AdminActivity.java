package com.miguellanches.comanda;

import android.app.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.GradientDrawable;import android.os.Bundle;import android.text.InputType;import android.view.*;import android.widget.*;import java.util.*;

public class AdminActivity extends Activity {
 ArrayList<Product> products; LinearLayout list, ingredientsList; int purple=Color.rgb(91,45,179),dark=Color.rgb(45,24,91),bg=Color.rgb(247,245,251); int dp(float v){return(int)(v*getResources().getDisplayMetrics().density+0.5f);}
 TextView tv(String s,float z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);t.setTypeface(Typeface.DEFAULT,b?Typeface.BOLD:Typeface.NORMAL);return t;}
 GradientDrawable shape(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
 Button b(String s){Button x=new Button(this);x.setText(s);x.setAllCaps(false);x.setTextColor(Color.WHITE);x.setTextSize(12);x.setTypeface(Typeface.DEFAULT,Typeface.BOLD);x.setBackground(shape(purple,13));return x;}
 @Override public void onCreate(Bundle x){super.onCreate(x);products=MenuStore.load(this);build();}
 void build(){
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
  TextView bar=tv("‹  EDITAR CARDÁPIO",20,Color.WHITE,true);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(10),0,0,0);bar.setBackgroundColor(purple);bar.setOnClickListener(v->finish());root.addView(bar,new LinearLayout.LayoutParams(-1,dp(58)));
  ScrollView sv=new ScrollView(this);LinearLayout all=new LinearLayout(this);all.setOrientation(LinearLayout.VERTICAL);all.setPadding(dp(10),dp(8),dp(10),dp(90));
  TextView info=tv("⚙  PRODUTOS\nEdite nome e preço ou adicione novos produtos.\n\n🥬 INGREDIENTES POR CATEGORIA\nEsses ingredientes aparecem na tela do produto para você marcar como adicionais.",14,Color.DKGRAY,false);info.setPadding(dp(6),dp(6),dp(6),dp(10));all.addView(info);
  list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);all.addView(list);
  Button add=b("＋  ADICIONAR PRODUTO");add.setOnClickListener(v->addProduct());all.addView(add,new LinearLayout.LayoutParams(-1,dp(55)));
  TextView sep=tv("INGREDIENTES ADICIONAIS",18,dark,true);sep.setPadding(dp(5),dp(18),0,dp(8));all.addView(sep);
  ingredientsList=new LinearLayout(this);ingredientsList.setOrientation(LinearLayout.VERTICAL);all.addView(ingredientsList);
  sv.addView(all);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);render();renderIngredients();
 }
 void render(){list.removeAllViews();for(Product p:products){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(8),dp(12),dp(10));box.setBackground(shape(Color.WHITE,14));TextView cat=tv(p.category,12,purple,true);box.addView(cat,new LinearLayout.LayoutParams(-1,dp(24)));LinearLayout line=new LinearLayout(this);EditText name=new EditText(this);name.setText(p.name);name.setSingleLine(true);name.setTextSize(14);EditText price=new EditText(this);price.setText(String.format(Locale.US,"%.2f",p.price));price.setSingleLine(true);price.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);Button save=b("SALVAR"),del=b("EXCLUIR");line.addView(name,new LinearLayout.LayoutParams(0,dp(50),1));line.addView(price,new LinearLayout.LayoutParams(dp(80),dp(50)));line.addView(save,new LinearLayout.LayoutParams(dp(76),dp(50)));line.addView(del,new LinearLayout.LayoutParams(dp(76),dp(50)));save.setOnClickListener(v->{p.name=name.getText().toString().trim();try{p.price=Double.parseDouble(price.getText().toString().replace(",","."));}catch(Exception e){}MenuStore.save(this,products);Toast.makeText(this,"Produto salvo",Toast.LENGTH_SHORT).show();render();});del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Excluir produto?").setMessage(p.name).setNegativeButton("Cancelar",null).setPositiveButton("Excluir",(d,w)->{products.remove(p);MenuStore.save(this,products);render();}).show());box.addView(line);list.addView(box,new LinearLayout.LayoutParams(-1,dp(92)));Space sp=new Space(this);list.addView(sp,new LinearLayout.LayoutParams(1,dp(7)));}}
 void addProduct(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);Spinner cat=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,MenuStore.CATEGORIES);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);cat.setAdapter(a);EditText n=new EditText(this);n.setHint("Nome do produto");EditText pr=new EditText(this);pr.setHint("Preço");pr.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);l.addView(cat);l.addView(n);l.addView(pr);new AlertDialog.Builder(this).setTitle("Novo produto").setView(l).setNegativeButton("Cancelar",null).setPositiveButton("Adicionar",(d,w)->{String name=n.getText().toString().trim();if(name.isEmpty())return;double price=0;try{price=Double.parseDouble(pr.getText().toString().replace(",","."));}catch(Exception e){}products.add(new Product((String)cat.getSelectedItem(),name,price));MenuStore.save(this,products);render();}).show();}

 void renderIngredients(){
  ingredientsList.removeAllViews();
  LinkedHashMap<String,ArrayList<String>> data=MenuStore.loadIngredients(this);
  for(String cat:MenuStore.CATEGORIES){
   LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(10),dp(12),dp(10));box.setBackground(shape(Color.WHITE,14));
   TextView title=tv(cat,15,purple,true);box.addView(title,new LinearLayout.LayoutParams(-1,dp(28)));
   EditText edit=new EditText(this);edit.setText(join(data.get(cat),", "));edit.setHint("Ex.: BACON, QUEIJO, CEBOLA");edit.setSingleLine(false);edit.setMinLines(2);edit.setTextSize(13);edit.setBackground(shape(Color.rgb(248,248,248),10));edit.setPadding(dp(10),dp(6),dp(10),dp(6));box.addView(edit,new LinearLayout.LayoutParams(-1,dp(70)));
   Button save=b("SALVAR INGREDIENTES");box.addView(save,new LinearLayout.LayoutParams(-1,dp(46)));save.setOnClickListener(v->{ArrayList<String> arr=parse(edit.getText().toString());LinkedHashMap<String,ArrayList<String>> all=MenuStore.loadIngredients(this);all.put(cat,arr);MenuStore.saveIngredients(this,all);Toast.makeText(this,cat+" atualizado",Toast.LENGTH_SHORT).show();});
   ingredientsList.addView(box,new LinearLayout.LayoutParams(-1,dp(154)));Space sp=new Space(this);ingredientsList.addView(sp,new LinearLayout.LayoutParams(1,dp(8)));
  }
 }
 String join(ArrayList<String> a,String sep){if(a==null)return "";StringBuilder b=new StringBuilder();for(int i=0;i<a.size();i++){if(i>0)b.append(sep);b.append(a.get(i));}return b.toString();}
 ArrayList<String> parse(String s){ArrayList<String> a=new ArrayList<>();for(String x:s.split(",")){x=x.trim();if(!x.isEmpty())a.add(x.toUpperCase(Locale.ROOT));}return a;}
}
