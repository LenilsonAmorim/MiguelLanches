# Miguel Lanches — Comanda Unificada

Base unificada do pedido + comanda + edição do cardápio.

## O que já vem
- Layout roxo limpo inspirado na referência enviada.
- 5 categorias.
- Apenas 2 produtos iniciais por categoria.
- Toque no produto para adicionar à comanda.
- Tela de comanda com cliente, endereço, observações, total, limpar, compartilhar e imprimir.
- Tela **Editar Cardápio** no menu ⋮.
- Edição de nome/preço, exclusão e inclusão de produtos.
- Dados do cardápio ficam salvos no aparelho.
