package br.com.miguellanches.comanda;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    final int PURPLE=Color.rgb(81,45,168), PURPLE_DARK=Color.rgb(74,20,140);
    LinearLayout root, products, cartBox, tabs;
    TextView cartTotal, cartTitle;
    String category="PIZZAS", size="M";
    final Map<String, Double> prices = new LinkedHashMap<>();
    final Map<String,Integer> cart = new LinkedHashMap<>();
    final Map<String,String> icons = new HashMap<>();

    String[][] data = {
        {"PIZZAS","A MODA DA CASA","24","34"},
        {"PIZZAS","MUSSARELA","22","32"},
        {"PIZZAS","FRANGO","22","32"},
        {"PIZZAS","MISTA","22","32"},
        {"PIZZAS","CALABRESA","24","34"},
        {"PIZZAS","QUATRO QUEIJOS","22","32"},
        {"PIZZAS","FRANGO C/ CATUPIRY","24","34"},
        {"PIZZAS","FRANGO C/ BACON","26","36"},
        {"PIZZAS","FRANGO C/ CHEDDAR","24","34"},
        {"PIZZAS","PORTUGUESA","24","34"},
        {"PASTÉIS","CARNE","9","13"},
        {"PASTÉIS","QUEIJO","9","13"},
        {"PASTÉIS","PIZZA","10","14"},
        {"PASTÉIS","FRANGO","10","14"},
        {"PASTÉIS","FRANGO C/ CATUPIRY","11","15"},
        {"PASTÉIS","CARNE C/ QUEIJO","11","15"},
        {"PASTÉIS","BACON","11","15"},
        {"PASTÉIS","CALABRESA","11","15"},
        {"PASTÉIS","PORTUGUESA","11","15"},
        {"PASTÉIS","4 QUEIJOS","12","16"},
        {"PORÇÕES","BATATA FRITA","16","24"},
        {"PORÇÕES","BATATA C/ CHEDDAR E BACON","22","32"},
        {"PORÇÕES","POLENTA FRITA","16","24"},
        {"PORÇÕES","MANDIOCA FRITA","16","24"},
        {"PORÇÕES","ANEL DE CEBOLA","18","26"},
        {"CHURRASCO","ESPETINHO DE CARNE","10","16"},
        {"CHURRASCO","ESPETINHO DE FRANGO","10","16"},
        {"SANDUÍCHES","MIGUEL BURG CASA","15","22"},
        {"SANDUÍCHES","MIGUEL BURG FRANGO","14","21"},
        {"SANDUÍCHES","X-TUDO BURG","20","28"}
    };

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        for(String[] x:data){ icons.put(x[0], iconFor(x[0])); }
        buildMain();
    }

    String iconFor(String c){
        if(c.equals("PIZZAS")) return "🍕";
        if(c.equals("PASTÉIS")) return "🥟";
        if(c.equals("PORÇÕES")) return "🍟";
        if(c.equals("CHURRASCO")) return "🥩";
        if(c.equals("SANDUÍCHES")) return "🍔";
        return "🍽️";
    }

    TextView tv(String s,float sp,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    GradientDrawable bg(int color,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(r); return g; }
    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextSize(13);
        b.setTextColor(PURPLE); b.setBackground(bg(Color.WHITE,30)); return b;
    }

    void buildMain(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        setContentView(root);

        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(16,0,8,0); bar.setBackgroundColor(PURPLE);
        TextView menu=tv("☰",28,Color.WHITE); bar.addView(menu,new LinearLayout.LayoutParams(52,64));
        TextView title=tv("NOVO PEDIDO",18,Color.WHITE); title.setTypeface(null,1); bar.addView(title,new LinearLayout.LayoutParams(0,64,1));
        TextView more=tv("⋮",28,Color.WHITE); more.setGravity(Gravity.CENTER); bar.addView(more,new LinearLayout.LayoutParams(45,64));
        more.setOnClickListener(v->showMenu());
        root.addView(bar);

        ScrollView sv=new ScrollView(this);
        LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(14,12,14,110);
        sv.addView(body); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        TextView head=tv("🧾  NOVO PEDIDO",22,Color.BLACK); head.setTypeface(null,1); head.setGravity(Gravity.CENTER);
        body.addView(head,new LinearLayout.LayoutParams(-1,48));
        TextView hint=tv("Escolha uma categoria e toque no produto\npara adicionar à comanda",13,Color.DKGRAY); hint.setGravity(Gravity.CENTER);
        body.addView(hint,new LinearLayout.LayoutParams(-1,45));

        tabs=new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL);
        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); hs.addView(tabs);
        body.addView(hs,new LinearLayout.LayoutParams(-1,70)); rebuildTabs();

        TextView cat=tv("🍕  "+category,20,Color.BLACK); cat.setTypeface(null,1); cat.setGravity(Gravity.CENTER); body.addView(cat,new LinearLayout.LayoutParams(-1,48));

        LinearLayout sizes=new LinearLayout(this); sizes.setGravity(Gravity.CENTER); 
        Button m=btn("MÉDIO (M)"), g=btn("GRANDE (G)");
        sizes.addView(m,new LinearLayout.LayoutParams(0,58,1)); sizes.addView(g,new LinearLayout.LayoutParams(0,58,1));
        body.addView(sizes);
        m.setOnClickListener(v->{size="M"; refreshProducts();});
        g.setOnClickListener(v->{size="G"; refreshProducts();});

        products=new LinearLayout(this); products.setOrientation(LinearLayout.VERTICAL); body.addView(products);
        refreshProducts();

        cartBox=new LinearLayout(this); cartBox.setOrientation(LinearLayout.HORIZONTAL); cartBox.setGravity(Gravity.CENTER_VERTICAL);
        cartBox.setPadding(16,5,8,5); cartBox.setBackground(bg(Color.WHITE,35));
        cartTitle=tv("🧾 Comanda vazia",14,Color.DKGRAY); cartBox.addView(cartTitle,new LinearLayout.LayoutParams(0,58,1));
        Button see=btn("🛒 VER COMANDA"); see.setTextColor(Color.WHITE); see.setBackground(bg(PURPLE,35)); cartBox.addView(see,new LinearLayout.LayoutParams(150,52));
        see.setOnClickListener(v->showCart());
        root.addView(cartBox,new LinearLayout.LayoutParams(-1,68));
    }

    void rebuildTabs(){
        tabs.removeAllViews();
        String[] cs={"PIZZAS","PASTÉIS","CHURRASCO","SANDUÍCHES","PORÇÕES"};
        for(String c:cs){
            Button b=btn(icons.get(c)+"\n"+c);
            b.setTextSize(10); b.setMinWidth(78);
            if(c.equals(category)){ b.setTextColor(Color.WHITE); b.setBackground(bg(PURPLE,28)); }
            tabs.addView(b,new LinearLayout.LayoutParams(82,62));
            b.setOnClickListener(v->{category=c; size="M"; buildMain();});
        }
    }

    void refreshProducts(){
        if(products==null)return; products.removeAllViews();
        TextView lab=tv(category+" "+(category.equals("PIZZAS")||category.equals("PASTÉIS")||category.equals("PORÇÕES")?"(" + size + ")":""),15,PURPLE);
        lab.setGravity(Gravity.CENTER); lab.setTypeface(null,1); products.addView(lab,new LinearLayout.LayoutParams(-1,42));
        for(String[] x:data) if(x[0].equals(category)){
            String name=x[1], price=size.equals("G")?x[3]:x[2];
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(6,3,6,3);
            TextView ico=tv(icons.get(category),22,Color.DKGRAY); row.addView(ico,new LinearLayout.LayoutParams(44,48));
            TextView n=tv(name,13,Color.DKGRAY); n.setTypeface(null,1); row.addView(n,new LinearLayout.LayoutParams(0,48,1));
            TextView p=tv("R$ "+price+",00",12,PURPLE); p.setGravity(Gravity.CENTER); row.addView(p,new LinearLayout.LayoutParams(95,48));
            row.setBackground(bg(Color.WHITE,8));
            row.setOnClickListener(v->add(name,Double.parseDouble(price)));
            products.addView(row,new LinearLayout.LayoutParams(-1,52));
        }
    }

    void add(String name,double p){
        cart.put(name,cart.getOrDefault(name,0)+1); prices.put(name,p);
        cartTitle.setText("🧾 "+cart.size()+" item(ns) na comanda");
        Toast.makeText(this,name+" adicionado à comanda",Toast.LENGTH_SHORT).show();
    }

    void showCart(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(24,10,24,10);
        TextView t=tv("COMANDA",22,PURPLE); t.setTypeface(null,1); box.addView(t,new LinearLayout.LayoutParams(-1,55));
        double total=0;
        if(cart.isEmpty()) box.addView(tv("Nenhum produto selecionado",16,Color.DKGRAY));
        for(String n:cart.keySet()){
            double p=prices.get(n); int q=cart.get(n); total+=p*q;
            TextView r=tv(q+"x  "+n+"     R$ "+String.format(java.util.Locale.US,"%.2f",p*q).replace(".",","),14,Color.DKGRAY);
            box.addView(r,new LinearLayout.LayoutParams(-1,42));
        }
        TextView tot=tv("TOTAL: R$ "+String.format(java.util.Locale.US,"%.2f",total).replace(".",","),19,Color.BLACK); tot.setTypeface(null,1);
        box.addView(tot,new LinearLayout.LayoutParams(-1,55));
        LinearLayout actions=new LinearLayout(this); actions.setGravity(Gravity.CENTER);
        Button clear=btn("LIMPAR"), share=btn("COMPARTILHAR"), close=btn("FECHAR");
        actions.addView(clear); actions.addView(share); actions.addView(close); box.addView(actions);
        AlertDialog d=new AlertDialog.Builder(this).setView(box).create();
        clear.setOnClickListener(v->{cart.clear();prices.clear();cartTitle.setText("🧾 Comanda vazia");d.dismiss();});
        share.setOnClickListener(v->{
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,"MIGUEL LANCHES\\nCOMANDA\\n"+tot.getText()); startActivity(Intent.createChooser(i,"Compartilhar comanda"));
        });
        close.setOnClickListener(v->d.dismiss()); d.show();
    }

    void showMenu(){
        final String[] op={"Adicionar produto","Ver comanda","Limpar comanda"};
        new AlertDialog.Builder(this).setTitle("Miguel Lanches").setItems(op,(d,w)->{
            if(w==0) addProductDialog(); else if(w==1) showCart(); else {cart.clear();prices.clear();cartTitle.setText("🧾 Comanda vazia");}
        }).show();
    }

    void addProductDialog(){
        LinearLayout b=new LinearLayout(this); b.setOrientation(LinearLayout.VERTICAL); b.setPadding(28,5,28,5);
        EditText name=new EditText(this); name.setHint("Nome do produto"); b.addView(name);
        EditText price=new EditText(this); price.setHint("Preço"); price.setInputType(2|8192); b.addView(price);
        new AlertDialog.Builder(this).setTitle("Adicionar produto").setView(b)
            .setNegativeButton("CANCELAR",null).setPositiveButton("ADICIONAR",(d,w)->{
                if(name.getText().length()>0 && price.getText().length()>0){
                    try { double p=Double.parseDouble(price.getText().toString().replace(",",".")); cart.put(name.getText().toString(),cart.getOrDefault(name.getText().toString(),0)+1); prices.put(name.getText().toString(),p); cartTitle.setText("🧾 "+cart.size()+" item(ns) na comanda"); }
                    catch(Exception e){ Toast.makeText(this,"Preço inválido",Toast.LENGTH_SHORT).show(); }
                }
            }).show();
    }
}
