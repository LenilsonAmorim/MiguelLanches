package com.miguellanches.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private WebView webView;

    private static final String SITE =
            "https://lenilsonamorim.github.io/MiguelLanches/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setSupportMultipleWindows(false);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance()
                .setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient());

        webView.setWebViewClient(new WebViewClient() {

            @Override
            public boolean shouldOverrideUrlLoading(
                    WebView view,
                    WebResourceRequest request) {

                return tratarLink(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(
                    WebView view,
                    String url) {

                return tratarLink(url);
            }
        });

        webView.loadUrl(SITE);
    }

    private boolean tratarLink(String url) {

        // Abre somente o WhatsApp instalado no celular.
        if (url.startsWith("whatsapp://")) {
            try {
                Intent whatsapp = new Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse(url)
                );
                startActivity(whatsapp);
            } catch (ActivityNotFoundException ignored) {
                // Não abre WhatsApp Web como fallback.
            }
            return true;
        }

        // Suporte a intent:// direcionado ao WhatsApp.
        if (url.startsWith("intent://")) {
            try {
                Intent intent = Intent.parseUri(
                        url,
                        Intent.URI_INTENT_SCHEME
                );

                String pacote = intent.getPackage();

                if (pacote == null || pacote.equals("com.whatsapp")) {
                    startActivity(intent);
                }
            } catch (Exception ignored) {
            }
            return true;
        }

        // Bloqueia WhatsApp Web dentro do APK.
        if (url.startsWith("https://web.whatsapp.com/")) {
            return true;
        }

        return false;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
