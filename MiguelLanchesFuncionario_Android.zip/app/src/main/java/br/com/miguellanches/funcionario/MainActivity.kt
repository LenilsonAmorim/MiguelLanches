package br.com.miguellanches.funcionario

import android.Manifest
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.OutputStream
import java.util.Locale
import java.util.UUID

data class Product(
    val id: String,
    val category: String,
    val name: String,
    val description: String = "",
    val variants: LinkedHashMap<String, Double> = linkedMapOf(),
    val price: Double? = null
)

data class CartLine(
    val product: Product,
    val variant: String?,
    val unitPrice: Double,
    var qty: Int
)

class MainActivity : android.app.Activity() {

    private val blue = Color.rgb(25, 66, 175)
    private val red = Color.rgb(205, 43, 52)
    private val dark = Color.rgb(20, 20, 24)
    private val bg = Color.rgb(245, 247, 250)

    private val products = buildProducts()
    private val cart = mutableListOf<CartLine>()

    private lateinit var rootLayout: LinearLayout
    private lateinit var titleView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun baseRoot(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setBackgroundColor(bg)
        return r
    }

    private fun topBar(title: String, back: Boolean = false, actionText: String? = null, action: (() -> Unit)? = null): LinearLayout {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(18, 14, 12, 14)
        bar.setBackgroundColor(dark)

        if (back) {
            val b = TextView(this)
            b.text = "‹"
            b.textSize = 34f
            b.setTextColor(Color.WHITE)
            b.gravity = Gravity.CENTER
            b.setOnClickListener { showHome() }
            bar.addView(b, LinearLayout.LayoutParams(dp(42), dp(48)))
        }

        titleView = TextView(this)
        titleView.text = title
        titleView.textSize = 21f
        titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        titleView.setTextColor(Color.WHITE)
        titleView.gravity = Gravity.CENTER_VERTICAL
        bar.addView(titleView, LinearLayout.LayoutParams(0, dp(48), 1f))

        if (actionText != null) {
            val a = TextView(this)
            a.text = actionText
            a.textSize = 15f
            a.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            a.setTextColor(Color.WHITE)
            a.gravity = Gravity.CENTER
            a.setPadding(12, 0, 12, 0)
            a.setOnClickListener { action?.invoke() }
            bar.addView(a, LinearLayout.LayoutParams(dp(120), dp(48)))
        }
        return bar
    }

    private fun showHome() {
        rootLayout = baseRoot()
        rootLayout.addView(topBar("MIGUEL LANCHES", false, "COMANDA ${cartQty()}") { showCart() })

        val subtitle = TextView(this)
        subtitle.text = "Comanda do funcionário"
        subtitle.textSize = 14f
        subtitle.setTextColor(Color.DKGRAY)
        subtitle.setPadding(18, 12, 18, 8)
        rootLayout.addView(subtitle)

        val scroll = ScrollView(this)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(14, 4, 14, 90)

        val categories = listOf(
            "Miguel Pizza" to "pizza.jpg",
            "Miguel Açaí" to "acai.jpg",
            "Miguel Sanduíches" to "sanduiches.jpg",
            "Miguel Pastéis" to "pasteis.jpg",
            "Miguel na Chapa / Churrasco" to "churrasco.jpg",
            "Milk Shake e Sucos" to "milkshake_sucos.jpg",
            "Porções e Petiscos" to null,
        )
        categories.forEach { (name, image) ->
            list.addView(categoryCard(name, image))
        }
        scroll.addView(list)
        rootLayout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(rootLayout)
    }

    private fun categoryCard(name: String, image: String?): LinearLayout {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(10, 8, 10, 8)
        card.setBackgroundColor(Color.WHITE)
        val lp = LinearLayout.LayoutParams(-1, dp(94))
        lp.setMargins(0, 7, 0, 7)
        card.layoutParams = lp

        if (image != null) {
            val img = ImageView(this)
            val resId = resources.getIdentifier(image.removeSuffix(".jpg"), "drawable", packageName)
            img.setImageResource(resId)
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            card.addView(img, LinearLayout.LayoutParams(dp(110), dp(78)))
        } else {
            val box = TextView(this)
            box.text = "🍟"
            box.textSize = 40f
            box.gravity = Gravity.CENTER
            card.addView(box, LinearLayout.LayoutParams(dp(110), dp(78)))
        }

        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.setPadding(14, 0, 0, 0)
        val t = TextView(this)
        t.text = name
        t.textSize = 18f
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        t.setTextColor(blue)
        texts.addView(t)
        val s = TextView(this)
        s.text = "Toque para abrir"
        s.textSize = 13f
        s.setTextColor(Color.DKGRAY)
        texts.addView(s)
        card.addView(texts, LinearLayout.LayoutParams(0, -1, 1f))

        card.setOnClickListener { showCategory(name) }
        return card
    }

    private fun showCategory(category: String) {
        rootLayout = baseRoot()
        rootLayout.addView(topBar(category, true, "COMANDA ${cartQty()}") { showCart() })
        val scroll = ScrollView(this)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(12, 10, 12, 90)

        products.filter { it.category == category }.forEach { p ->
            list.addView(productRow(p))
        }
        scroll.addView(list)
        rootLayout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(rootLayout)
    }

    private fun productRow(p: Product): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.VERTICAL
        row.setPadding(14, 10, 14, 10)
        row.setBackgroundColor(Color.WHITE)
        val lp = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 0, 0, 8)
        row.layoutParams = lp

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        val n = TextView(this)
        n.text = p.name
        n.textSize = 17f
        n.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        n.setTextColor(dark)
        top.addView(n, LinearLayout.LayoutParams(0, -2, 1f))

        val priceText = if (p.variants.isNotEmpty()) {
            "a partir de R$ %.2f".format(Locale("pt","BR"), p.variants.values.minOrNull() ?: 0.0)
        } else {
            "R$ %.2f".format(Locale("pt","BR"), p.price ?: 0.0)
        }
        val pr = TextView(this)
        pr.text = priceText
        pr.textSize = 16f
        pr.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        pr.setTextColor(red)
        top.addView(pr)
        row.addView(top)

        if (p.description.isNotBlank()) {
            val d = TextView(this)
            d.text = p.description
            d.textSize = 12f
            d.setTextColor(Color.GRAY)
            d.setPadding(0, 3, 0, 0)
            row.addView(d)
        }

        row.setOnClickListener {
            if (p.variants.isNotEmpty()) chooseVariant(p)
            else addToCart(p, null, p.price ?: 0.0)
        }
        return row
    }

    private fun chooseVariant(p: Product) {
        val labels = p.variants.keys.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(p.name)
            .setItems(labels) { _, which ->
                val label = labels[which]
                addToCart(p, label, p.variants[label]!!)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun addToCart(p: Product, variant: String?, price: Double) {
        val existing = cart.firstOrNull { it.product.id == p.id && it.variant == variant }
        if (existing != null) existing.qty++ else cart.add(CartLine(p, variant, price, 1))
        Toast.makeText(this, "Adicionado: ${p.name}", Toast.LENGTH_SHORT).show()
        titleView.text = "${p.category} • ${cartQty()} itens"
    }

    private fun cartQty() = cart.sumOf { it.qty }

    private fun total(): Double = cart.sumOf { it.qty * it.unitPrice }

    private fun showCart() {
        rootLayout = baseRoot()
        rootLayout.addView(topBar("COMANDA", true, "LIMPAR") {
            cart.clear()
            showCart()
        })

        val main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL
        main.setPadding(12, 10, 12, 10)

        fun field(hint: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText {
            val e = EditText(this)
            e.hint = hint
            e.inputType = type
            e.setSingleLine(false)
            e.setPadding(14, 8, 14, 8)
            return e
        }

        val client = field("Cliente")
        val address = field("Endereço")
        val obs = field("Observações")
        main.addView(client, LinearLayout.LayoutParams(-1, dp(58)))
        main.addView(address, LinearLayout.LayoutParams(-1, dp(58)))

        val scroll = ScrollView(this)
        val lines = LinearLayout(this)
        lines.orientation = LinearLayout.VERTICAL
        lines.setPadding(0, 8, 0, 8)

        if (cart.isEmpty()) {
            val empty = TextView(this)
            empty.text = "Nenhum item na comanda."
            empty.textSize = 17f
            empty.setPadding(12, 30, 12, 30)
            empty.gravity = Gravity.CENTER
            lines.addView(empty)
        } else {
            cart.forEach { line ->
                val r = LinearLayout(this)
                r.orientation = LinearLayout.HORIZONTAL
                r.setPadding(12, 10, 12, 10)
                r.setBackgroundColor(Color.WHITE)
                val name = TextView(this)
                name.text = "${line.qty}x ${line.product.name}${if (line.variant != null) " (${line.variant})" else ""}"
                name.textSize = 15f
                name.setTextColor(dark)
                r.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
                val value = TextView(this)
                value.text = "R$ %.2f".format(Locale("pt","BR"), line.qty * line.unitPrice)
                value.textSize = 15f
                value.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                value.setTextColor(red)
                r.addView(value)
                r.setOnClickListener {
                    line.qty--
                    if (line.qty <= 0) cart.remove(line)
                    showCart()
                }
                val p = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)
                p.setMargins(0, 0, 0, 5)
                lines.addView(r, p)
            }
        }
        scroll.addView(lines)
        main.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        main.addView(obs, LinearLayout.LayoutParams(-1, dp(72)))

        val totalView = TextView(this)
        totalView.text = "TOTAL: R$ %.2f".format(Locale("pt","BR"), total())
        totalView.textSize = 22f
        totalView.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        totalView.setTextColor(blue)
        totalView.setGravity(Gravity.END)
        totalView.setPadding(12, 10, 12, 10)
        main.addView(totalView)

        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL

        val share = bigButton("COMPARTILHAR", false)
        val print = bigButton("IMPRIMIR", true)
        share.setOnClickListener {
            val text = makeReceipt(client.text.toString(), address.text.toString(), obs.text.toString())
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }, "Compartilhar pedido"))
        }
        print.setOnClickListener {
            val text = makeReceipt(client.text.toString(), address.text.toString(), obs.text.toString())
            chooseBluetoothPrinter(text)
        }

        actions.addView(share, LinearLayout.LayoutParams(0, dp(58), 1f))
        actions.addView(print, LinearLayout.LayoutParams(0, dp(58), 1f))
        main.addView(actions)

        rootLayout.addView(main, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(rootLayout)
    }

    private fun bigButton(text: String, primary: Boolean): Button {
        val b = Button(this)
        b.text = text
        b.textSize = 15f
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        b.setTextColor(if (primary) Color.WHITE else blue)
        b.setBackgroundColor(if (primary) blue else Color.WHITE)
        return b
    }

    private fun makeReceipt(client: String, address: String, obs: String): String {
        val sb = StringBuilder()
        sb.appendLine("================================")
        sb.appendLine(center("MIGUEL LANCHES", 32))
        sb.appendLine("================================")
        sb.appendLine("PEDIDO: #001")
        sb.appendLine()
        if (client.isNotBlank()) sb.appendLine("CLIENTE: $client")
        if (address.isNotBlank()) sb.appendLine("ENDERECO: $address")
        if (client.isNotBlank() || address.isNotBlank()) sb.appendLine("--------------------------------")
        sb.appendLine("QTD  ITEM                VALOR")
        sb.appendLine("--------------------------------")
        cart.forEach { line ->
            val label = buildString {
                append(line.product.name)
                if (line.variant != null) append(" - ${line.variant}")
            }
            sb.appendLine(formatItem(line.qty, label, line.qty * line.unitPrice))
        }
        sb.appendLine("--------------------------------")
        if (obs.isNotBlank()) {
            sb.appendLine("OBSERVACOES:")
            sb.appendLine(obs)
            sb.appendLine("--------------------------------")
        }
        sb.appendLine(String.format(Locale("pt","BR"), "TOTAL:                  R$ %.2f", total()))
        sb.appendLine("================================")
        sb.appendLine(center("Obrigado!", 32))
        return sb.toString()
    }

    private fun formatItem(qty: Int, item: String, value: Double): String {
        val name = item.take(19).padEnd(19, ' ')
        return String.format(Locale.US, "%02d  %s R$ %5.2f", qty, name, value)
    }

    private fun center(s: String, width: Int): String {
        if (s.length >= width) return s.take(width)
        val left = (width - s.length) / 2
        return " ".repeat(left) + s
    }

    private fun chooseBluetoothPrinter(receipt: String) {
        if (android.os.Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 77)
            return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            Toast.makeText(this, "Bluetooth não disponível.", Toast.LENGTH_LONG).show()
            return
        }
        val devices: Set<BluetoothDevice> = try { adapter.bondedDevices } catch (e: SecurityException) { emptySet() }
        if (devices.isEmpty()) {
            Toast.makeText(this, "Pareie a impressora nas configurações do Bluetooth primeiro.", Toast.LENGTH_LONG).show()
            return
        }
        val names = devices.map { "${it.name ?: "Sem nome"}\n${it.address}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Escolha a impressora")
            .setItems(names) { _, which ->
                Thread {
                    try {
                        val device = devices.toList()[which]
                        val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
                        val socket = device.createRfcommSocketToServiceRecord(uuid)
                        socket.connect()
                        val out: OutputStream = socket.outputStream
                        out.write(byteArrayOf(0x1B, 0x40))
                        out.write(receipt.toByteArray(Charsets.ISO_8859_1))
                        out.write(byteArrayOf(0x0A, 0x0A, 0x0A, 0x1D, 0x56, 0x00))
                        out.flush()
                        out.close()
                        socket.close()
                        runOnUiThread { Toast.makeText(this, "Pedido enviado para a impressora.", Toast.LENGTH_LONG).show() }
                    } catch (e: Exception) {
                        runOnUiThread { Toast.makeText(this, "Falha ao imprimir: ${e.message}", Toast.LENGTH_LONG).show() }
                    }
                }.start()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Permissão concedida. Toque em IMPRIMIR novamente.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    private fun p(id: String, category: String, name: String, desc: String = "", price: Double? = null, vararg vars: Pair<String, Double>) =
        Product(id, category, name, desc, linkedMapOf(*vars), price)

    private fun buildProducts(): List<Product> {
        val list = mutableListOf<Product>()
        fun pizza(id: Int, name: String, m: Double, g: Double, desc: String = "") {
            list += p("p$id", "Miguel Pizza", name, desc, null, "Médio" to m, "Grande" to g)
        }
        pizza(1, "A Moda da Casa", 24.0, 30.0)
        pizza(2, "Mussarela", 22.0, 28.0)
        pizza(3, "Frango", 22.0, 28.0)
        pizza(4, "Mista", 22.0, 28.0)
        pizza(5, "Calabresa", 24.0, 30.0)
        pizza(6, "Quatro Queijos", 22.0, 28.0)
        pizza(7, "Frango c/ Catupiry", 24.0, 30.0)
        pizza(8, "Frango c/ Bacon", 26.0, 32.0)
        pizza(9, "Frango c/ Cheddar", 24.0, 30.0)
        pizza(10, "Portuguesa", 24.0, 30.0)
        pizza(11, "Sertaneja", 27.0, 33.0)
        pizza(12, "Americana", 26.0, 32.0)
        pizza(13, "Mussarela c/ Catupiry", 24.0, 30.0)
        pizza(14, "Mussarela c/ Cheddar", 24.0, 30.0)
        pizza(15, "Calabresa c/ Catupiry", 26.0, 32.0)
        pizza(16, "Calabresa c/ Cheddar", 26.0, 32.0)
        pizza(17, "Carne de Sol c/ Catupiry", 27.0, 33.0)
        pizza(18, "Carne de Sol c/ Cheddar", 27.0, 33.0)
        pizza(19, "Frango c/ Catupiry e Bacon", 26.0, 32.0)
        pizza(20, "Frango c/ Catupiry e Cheddar", 26.0, 32.0)
        pizza(21, "Calabresa, Mussarela e Cheddar", 26.0, 32.0)
        pizza(22, "Calabresa, Ovo Cozido, Cebola e Mussarela", 27.0, 33.0)
        pizza(23, "Miguel Suprema", 27.0, 33.0)
        pizza(24, "Pizza Sensação - Chocolate", 27.0, 33.0)
        pizza(25, "Frango e Milho Verde", 26.0, 30.0)
        pizza(26, "Mesclada", 27.0, 33.0)
        pizza(26_1, "Qualquer Pizza Meio a Meio", 33.0, 33.0)

        fun pastel(id: Int, name: String, m: Double, g: Double) {
            list += p("t$id", "Miguel Pastéis", name, null, null, "Médio" to m, "Grande" to g)
        }
        pastel(27, "Pastel Mussarela", 7.0, 10.0)
        pastel(28, "Pastel Frango", 7.0, 9.0)
        pastel(29, "Pastel Frango e Queijo", 8.0, 10.0)
        pastel(30, "Pastel Frango c/ Bacon", 10.0, 12.0)
        pastel(31, "Pastel Frango c/ Catupiry", 8.0, 10.0)
        pastel(32, "Pastel Frango c/ Cheddar", 8.0, 10.0)
        pastel(33, "Pastel Frango c/ Milho", 8.0, 10.0)
        pastel(34, "Pastel Queijo e Presunto", 8.0, 10.0)
        pastel(35, "Pastel Calabresa", 7.0, 9.0)
        pastel(36, "Pastel Calabresa c/ Queijo", 9.0, 12.0)
        pastel(37, "Pastel Sertanejo", 10.0, 12.0)
        pastel(38, "Pastel Pizza", 10.0, 12.0)
        pastel(39, "Pastel Bacon c/ Queijo", 10.0, 12.0)
        pastel(40, "Pastel Carne de Sol c/ Catupiry", 10.0, 12.0)
        pastel(41, "Pastel Carne de Sol c/ Cheddar", 10.0, 12.0)
        pastel(42, "Pastel Carne de Sol c/ Queijo Coalho", 10.0, 12.0)
        pastel(43, "Pastel Carne de Sol c/ Bacon", 10.0, 12.0)
        pastel(44, "Pastel Bacon c/ Cheddar", 10.0, 12.0)
        pastel(45, "Pastel de Quatro Queijos", 10.0, 12.0)
        pastel(46, "Pastel Chinês", 10.0, 12.0)
        pastel(47, "Pastel Romeu e Julieta", 10.0, 13.0)
        pastel(48, "Pastel Chocolate Branco", 10.0, 12.0)
        pastel(49, "Pastel Chocolate Preto", 10.0, 13.0)
        pastel(50, "Pastel Chocolate Preto c/ Queijo", 11.0, 14.0)

        fun sand(id: Int, name: String, price: Double) {
            list += p("s$id", "Miguel Sanduíches", name, null, price)
        }
        sand(51, "Miguel Burg", 12.0)
        sand(52, "Miguel Cheddar", 10.0)
        sand(53, "Miguel Bacon", 10.0)
        sand(54, "Miguel Bauru Burg Especial", 10.0)
        sand(55, "Miguel Burg Calabresa", 13.0)
        sand(56, "Miguel Burg Frango", 13.0)
        sand(57, "Miguel Burg Frango Catupiry", 14.0)
        sand(58, "Miguel X-Tudo Burg", 14.0)
        sand(59, "Miguel Burg Duplo", 18.0)
        sand(60, "Miguel Burg Sertanejo", 18.0)
        sand(61, "Miguel Burg da Casa", 15.0)
        sand(62, "Miguel Burg Quarteirão", 20.0)
        list += p("dog63", "Miguel Sanduíches", "Miguel Dogão", "Pão, salsicha, carne moída, milho, frango desfiado, batata palha, queijo ralado e molho especial.", 5.0)

        list += p("pet64", "Porções e Petiscos", "Frango Crocante c/ Fritas", "Preço conforme cadastro original.", null)
        list += p("pet65", "Porções e Petiscos", "Miguel Filé c/ Fritas", null, 33.0)

        fun por(id: Int, name: String, g: Double, m: Double) {
            list += p("por$id", "Porções e Petiscos", name, "Grande / Média", null, "Grande" to g, "Média" to m)
        }
        por(66, "Batata Frita c/ Queijo Cheddar", 17.0, 14.0)
        por(67, "Batata Frita c/ Bacon", 17.0, 15.0)
        por(68, "Batata Frita c/ Calabresa", 16.0, 12.0)
        por(69, "Batata Frita c/ Cheddar e Bacon", 19.0, 16.0)
        por(70, "Batata Frita c/ Cheddar e Calabresa", 19.0, 16.0)
        por(71, "Batata Frita c/ Calabresa", 17.0, 14.0)

        // Açaí
        val acaiSizes = listOf("200ml" to 8.0, "300ml" to 12.0, "500ml" to 15.0, "1 Litro" to 28.0)
        list += p("acai", "Miguel Açaí", "Açaí", "Direito a 3 coberturas.", null, *acaiSizes.toTypedArray())
        list += p("cream", "Miguel Açaí", "Creme de Ovomaltine / Ninho / Morango / Amendoim / Cupuaçu", "Escolha o creme.", null, *acaiSizes.toTypedArray())

        // Churrasco
        fun churr(id: String, name: String, price: Double) = list += p(id, "Miguel na Chapa / Churrasco", name, null, price)
        churr("ch1", "Carne Bovina", 7.0)
        churr("ch2", "Filé de Frango", 7.0)
        churr("ch3", "Língua Bovina", 7.0)
        churr("ch4", "Coração de Frango", 7.0)
        churr("ch5", "Queijo de Coalho", 8.0)
        churr("ch6", "Carne Suína", 7.0)
        churr("ch7", "Carne c/ Bacon", 8.0)
        churr("ch8", "Frango c/ Bacon", 8.0)
        churr("ch9", "Capirinha (copo 300ml)", 7.0)
        churr("ch10", "Caipirosca (copo 300ml)", 8.0)

        // Milk shake
        list += p("ms", "Milk Shake e Sucos", "Milk Shake", "Chocolate, Ovomaltine, Morango, Ninho com Ovomaltine, Morango com Ovomaltine, Creme, Creme com Ovomaltine. Caldas: morango, chocolate preto e caramelo.", null,
            "300ml" to 12.0, "500ml" to 14.0)

        // Sucos
        val sucos = listOf("Cajá", "Uva", "Morango", "Acerola", "Cajú", "Graviola", "Goiaba", "Maracujá", "Cupuaçu", "Abacaxi", "Abacaxi com Hortelã", "Siriguela", "Jaca", "Manga", "Mangaba", "Tangerina", "Limão")
        list += p("suco", "Milk Shake e Sucos", "Suco Natural", sucos.joinToString(", "), null,
            "300ml na água" to 5.0, "300ml ao leite" to 7.0,
            "500ml na água" to 6.0, "500ml ao leite" to 9.0,
            "Jarra 1L na água" to 12.0, "Jarra 1L ao leite" to 18.0)
        list += p("laranja", "Milk Shake e Sucos", "Suco Natural de Laranja", null, null,
            "300ml" to 5.0, "500ml" to 8.0, "Jarra 1L" to 18.0)

        return list
    }
}
