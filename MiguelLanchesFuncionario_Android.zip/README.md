# Miguel Lanches — App Funcionário

Primeira versão do app Android nativo para lançar pedidos e imprimir em impressora térmica Bluetooth.

## O que já existe
- Categorias com as imagens do seu cardápio.
- Produtos e preços transcritos das imagens enviadas.
- Variações de tamanho (ex.: pizza médio/grande; pastel médio/grande; porções).
- Carrinho/comanda.
- Cliente, endereço e observações.
- Compartilhar pedido.
- Impressão ESC/POS via Bluetooth para impressoras pareadas.
- Layout simples e rápido para funcionário.

## Observação importante
O ambiente desta conversa não possui Android SDK/Gradle configurado para gerar um APK instalável aqui. O arquivo enviado é o projeto Android fonte, para abrir no Android Studio e gerar o APK.

## Como gerar o APK
1. Abra a pasta no Android Studio.
2. Espere o Gradle sincronizar.
3. Conecte o celular ou use um emulador.
4. Rode o projeto ou use Build > Generate App Bundle / APK > Generate APK.
5. No Android 12+, conceda permissão de Bluetooth quando solicitado.
6. Pareie a impressora térmica no Bluetooth do aparelho antes de imprimir.

## Ponto a conferir no cardápio
O item 64 "Frango Crocante c/ Fritas" apareceu sem preço legível na foto original; por isso ficou sem preço no app para não inventar valor.
