package com.miguellanches.comanda;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    LinearLayout productList, categories;
    HorizontalScrollView categoryScroll;
    TextView categoryTitle, countText;
    String selected = "PIZZAS";
    String sizeFilter = "M";
    ArrayList<Product> products;
    public static ArrayList<CartItem> cart = new ArrayList<>();
    NumberFormat money = NumberFormat.getCurrencyInstance(new Locale("pt","BR"));
    int purple=Color.rgb(91,45,179), dark=Color.rgb(45,24,91), bg=Color.rgb(247,245,251);

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    TextView tv(String s,float size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    GradientDrawable shape(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g; }
    TextView chip(String text, boolean active){
        TextView t=tv(text,12,active?Color.WHITE:dark,true); t.setGravity(Gravity.CENTER); t.setPadding(dp(4),0,dp(4),0);
        t.setBackground(shape(active?purple:Color.WHITE,18)); return t;
    }
    Button purpleButton(String s){
        Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setBackground(shape(purple,16)); b.setPadding(dp(4),0,dp(4),0); return b;
    }

    @Override public void onCreate(Bundle b){ super.onCreate(b); products=MenuStore.load(this); build(); }

    void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(12),0,dp(8),0); bar.setBackgroundColor(purple);
        TextView menu=tv("☰",28,Color.WHITE,false); bar.addView(menu,new LinearLayout.LayoutParams(dp(42),dp(58)));
        TextView title=tv("MIGUEL LANCHES",20,Color.WHITE,true); bar.addView(title,new LinearLayout.LayoutParams(0,dp(58),1));
        Button topOrders=purpleButton("📋 PEDIDOS"); topOrders.setTextSize(14); topOrders.setOnClickListener(v->{ Intent i=new Intent(this,OrderActivity.class); i.putExtra("OPEN_ORDERS",true); startActivity(i); });
        bar.addView(topOrders,new LinearLayout.LayoutParams(dp(138),dp(50)));
        TextView edit=tv("⚙",24,Color.WHITE,false); edit.setGravity(Gravity.CENTER); bar.addView(edit,new LinearLayout.LayoutParams(dp(46),dp(58)));
        edit.setOnClickListener(v->startActivity(new Intent(this,AdminActivity.class))); root.addView(bar);

        LinearLayout intro=new LinearLayout(this); intro.setOrientation(LinearLayout.VERTICAL); intro.setGravity(Gravity.CENTER); intro.setPadding(dp(10),dp(8),dp(10),dp(2));
        TextView h=tv("🧾  NOVO PEDIDO",24,Color.BLACK,true); h.setGravity(Gravity.CENTER); intro.addView(h,new LinearLayout.LayoutParams(-1,dp(38)));
        TextView hint=tv("Escolha uma categoria e toque no produto para adicionar à comanda",13,Color.DKGRAY,false); hint.setGravity(Gravity.CENTER); intro.addView(hint,new LinearLayout.LayoutParams(-1,dp(38))); root.addView(intro);

        categoryScroll=new HorizontalScrollView(this); categoryScroll.setHorizontalScrollBarEnabled(false); categoryScroll.setFillViewport(false);
        categories=new LinearLayout(this); categories.setGravity(Gravity.CENTER_VERTICAL); categories.setPadding(dp(10),dp(5),dp(10),dp(9)); categoryScroll.addView(categories); root.addView(categoryScroll,new LinearLayout.LayoutParams(-1,dp(64))); renderCategories();

        categoryTitle=tv("",20,dark,true); categoryTitle.setGravity(Gravity.CENTER); root.addView(categoryTitle,new LinearLayout.LayoutParams(-1,dp(44)));

        ScrollView sv=new ScrollView(this); productList=new LinearLayout(this); productList.setOrientation(LinearLayout.VERTICAL); productList.setPadding(dp(12),dp(4),dp(12),dp(95)); sv.addView(productList); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout bottom=new LinearLayout(this); bottom.setGravity(Gravity.CENTER_VERTICAL); bottom.setPadding(dp(12),dp(7),dp(12),dp(7)); bottom.setBackgroundColor(Color.WHITE);
        countText=tv("🧾 0 item(ns) na comanda",15,Color.DKGRAY,true); bottom.addView(countText,new LinearLayout.LayoutParams(0,dp(58),1));
        Button view=purpleButton("🛒  VER COMANDA"); bottom.addView(view,new LinearLayout.LayoutParams(dp(170),dp(50))); view.setOnClickListener(v->{ OrderActivity.cart=cart; startActivity(new Intent(this,OrderActivity.class)); }); root.addView(bottom);
        setContentView(root); render();
    }

    void renderCategories(){
        categories.removeAllViews(); String[] icons={"🍔","🍕","🥟","🍟","🍧","🥩","🥤"};
        for(int i=0;i<MenuStore.CATEGORIES.size();i++){
            String c=MenuStore.CATEGORIES.get(i); TextView cb=chip(icons[i]+"  "+c,c.equals(selected));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(112),dp(46)); lp.setMargins(dp(4),0,dp(4),0); categories.addView(cb,lp);
            cb.setOnClickListener(v->{ selected=c; sizeFilter="M"; renderCategories(); render(); });
        }
        categoryScroll.post(()->{
            for(int i=0;i<categories.getChildCount();i++){ View v=categories.getChildAt(i); if(v instanceof TextView && ((TextView)v).getText().toString().contains(selected)){ int left=v.getLeft(),right=v.getRight(),visible=categoryScroll.getWidth(); categoryScroll.scrollTo(Math.max(0,(left+right-visible)/2),0); break; } }
        });
    }

    boolean hasSizeControls(){ return selected.equals("PIZZAS") || selected.equals("PASTÉIS"); }
    boolean isMedium(Product p){
        String n=p.name.toUpperCase(Locale.ROOT);
        return n.contains("MÉDIA") || n.contains("MEDIA") || n.matches(".*(^|[^A-Z])M($|[^A-Z]).*") || n.endsWith(" M");
    }
    boolean isLarge(Product p){
        String n=p.name.toUpperCase(Locale.ROOT);
        return n.contains("GRANDE") || n.matches(".*(^|[^A-Z])G($|[^A-Z]).*") || n.endsWith(" G");
    }
    boolean matchesSize(Product p){
        if(!hasSizeControls()) return true;
        boolean m=isMedium(p), g=isLarge(p);
        if(m||g) return sizeFilter.equals("M")?m:g;
        // If an existing product has no size marker, keep it visible in both tabs.
        return true;
    }

    void render(){
        if(categoryTitle==null)return; categoryTitle.setText(selected); productList.removeAllViews();
        if(hasSizeControls()) renderSizeButtons();
        if(selected.equals("PIZZAS")) addHalfHalfCard();
        boolean any=false;
        for(Product p:products) if(p.category.equals(selected) && matchesSize(p)){ any=true; addProductCard(p); }
        if(!any && !selected.equals("PIZZAS")){
            TextView empty=tv("Nenhum produto cadastrado para este tamanho.",14,Color.GRAY,false); empty.setGravity(Gravity.CENTER); productList.addView(empty,new LinearLayout.LayoutParams(-1,dp(80)));
        }
        updateCount();
    }

    void renderSizeButtons(){
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER); row.setPadding(dp(12),0,dp(12),dp(6));
        TextView m=chip("M",sizeFilter.equals("M")), g=chip("G",sizeFilter.equals("G"));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(42),1); lp.setMargins(dp(4),0,dp(4),0); row.addView(m,lp); row.addView(g,new LinearLayout.LayoutParams(0,dp(42),1));
        m.setOnClickListener(v->{sizeFilter="M";render();}); g.setOnClickListener(v->{sizeFilter="G";render();});
        productList.addView(row,new LinearLayout.LayoutParams(-1,dp(48)));
    }

    void addHalfHalfCard(){
        LinearLayout card=new LinearLayout(this); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(10),dp(5),dp(8),dp(5)); card.setBackground(shape(Color.WHITE,15));
        TextView icon=tv("🍕",25,Color.BLACK,false); icon.setGravity(Gravity.CENTER); card.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(58)));
        LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL); texts.setGravity(Gravity.CENTER_VERTICAL);
        texts.addView(tv("Pizza Meio a Meio",15,Color.rgb(45,45,45),true),new LinearLayout.LayoutParams(-1,dp(31)));
        texts.addView(tv("Toque para escolher 2 sabores",11,Color.GRAY,false),new LinearLayout.LayoutParams(-1,dp(22))); card.addView(texts,new LinearLayout.LayoutParams(0,dp(68),1));
        TextView price=tv("Maior valor",13,purple,true); price.setGravity(Gravity.CENTER); card.addView(price,new LinearLayout.LayoutParams(dp(94),dp(68)));
        card.setOnClickListener(v->showHalfHalf()); productList.addView(card,new LinearLayout.LayoutParams(-1,dp(70))); Space sp=new Space(this); productList.addView(sp,new LinearLayout.LayoutParams(1,dp(7)));
    }

    void addProductCard(Product p){
        LinearLayout card=new LinearLayout(this); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(10),dp(5),dp(8),dp(5)); card.setBackground(shape(Color.WHITE,15));
        TextView icon=tv(iconFor(p.category),25,Color.BLACK,false); icon.setGravity(Gravity.CENTER); card.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(58)));
        LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL); texts.setGravity(Gravity.CENTER_VERTICAL);
        texts.addView(tv(p.name,15,Color.rgb(45,45,45),true),new LinearLayout.LayoutParams(-1,dp(31))); texts.addView(tv("Toque para adicionar",11,Color.GRAY,false),new LinearLayout.LayoutParams(-1,dp(22))); card.addView(texts,new LinearLayout.LayoutParams(0,dp(68),1));
        TextView price=tv(money.format(p.price),14,purple,true); price.setGravity(Gravity.CENTER); card.addView(price,new LinearLayout.LayoutParams(dp(94),dp(68)));
        card.setOnClickListener(v->showProductOptions(p)); productList.addView(card,new LinearLayout.LayoutParams(-1,dp(70))); Space sp=new Space(this); productList.addView(sp,new LinearLayout.LayoutParams(1,dp(7)));
    }

    void showHalfHalf(){
        ArrayList<Product> choices=new ArrayList<>(); for(Product p:products) if(p.category.equals("PIZZAS") && matchesSize(p)) choices.add(p);
        if(choices.size()==0){ Toast.makeText(this,"Cadastre os sabores da pizza primeiro.",Toast.LENGTH_SHORT).show(); return; }
        boolean[] selectedBox=new boolean[choices.size()]; final double[] maxPrice={0};
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(8),dp(2),dp(8),0);
        TextView info=tv("Selecione até 2 sabores",14,dark,true); box.addView(info,new LinearLayout.LayoutParams(-1,dp(34)));
        TextView total=tv("Valor: R$ 0,00",16,purple,true); total.setGravity(Gravity.CENTER); box.addView(total,new LinearLayout.LayoutParams(-1,dp(32)));
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        ArrayList<CheckBox> checks=new ArrayList<>();
        for(int i=0;i<choices.size();i++){
            Product p=choices.get(i); CheckBox cb=new CheckBox(this); cb.setText(p.name+"  ("+money.format(p.price)+")"); cb.setTextSize(14); cb.setTextColor(Color.DKGRAY); checks.add(cb); final int idx=i;
            cb.setOnCheckedChangeListener((button,ok)->{
                int count=0; double max=0; for(int j=0;j<checks.size();j++) if(checks.get(j).isChecked()){count++;max=Math.max(max,choices.get(j).price);}
                if(ok && count>2){ button.setChecked(false); Toast.makeText(this,"Escolha no máximo 2 sabores.",Toast.LENGTH_SHORT).show(); return; }
                maxPrice[0]=max; total.setText("Valor: "+money.format(max)); info.setText(count+" de 2 sabores selecionados");
            });
            list.addView(cb,new LinearLayout.LayoutParams(-1,dp(44)));
        }
        ScrollView sc=new ScrollView(this); sc.addView(list); box.addView(sc,new LinearLayout.LayoutParams(-1,dp(Math.min(300,Math.max(80,choices.size()*44)))));
        EditText note=new EditText(this); note.setHint("Observação (opcional)"); note.setSingleLine(false); note.setMinLines(2); note.setBackground(shape(Color.WHITE,12)); note.setPadding(dp(10),dp(6),dp(10),dp(6)); box.addView(note,new LinearLayout.LayoutParams(-1,dp(62)));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("PIZZA MEIO A MEIO • "+sizeFilter).setView(box).setNegativeButton("CANCELAR",null).setPositiveButton("ADICIONAR",null).create();
        dialog.setOnShowListener(x->{ dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(purple); dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            ArrayList<String> flavors=new ArrayList<>(); for(int i=0;i<checks.size();i++) if(checks.get(i).isChecked()) flavors.add(choices.get(i).name);
            if(flavors.size()!=2){ Toast.makeText(this,"Escolha 2 sabores para a meio a meio.",Toast.LENGTH_SHORT).show(); return; }
            Product pp=new Product("PIZZAS","Pizza Meio a Meio: "+flavors.get(0)+" / "+flavors.get(1),maxPrice[0]);
            ArrayList<String> ex=new ArrayList<>(flavors); String n=note.getText().toString().trim(); CartItem found=null; for(CartItem ci:cart) if(ci.sameConfiguration(pp,n,ex)){found=ci;break;}
            if(found==null) cart.add(new CartItem(pp,1,n,ex)); else found.quantity++;
            updateCount(); dialog.dismiss(); Toast.makeText(this,"Pizza meio a meio adicionada",Toast.LENGTH_SHORT).show();
        }); }); dialog.show();
    }

    boolean allowExtras(String cat){ return cat.equals("SANDUÍCHES") || (cat.equals("AÇAÍ")); }
    boolean allowNote(String cat){ return cat.equals("SANDUÍCHES") || cat.equals("PIZZAS") || cat.equals("CHURRASCO"); }
    boolean noOptions(String cat){ return cat.equals("BEBIDAS") || cat.equals("PORÇÕES") || cat.equals("PASTÉIS"); }

    void showProductOptions(Product p){
        final int[] qty={1};
        boolean extrasAllowed=allowExtras(p.category), noteAllowed=allowNote(p.category);
        if(noOptions(p.category)) { showSimpleProduct(p,false); return; }
        ArrayList<String> rawIngredients=extrasAllowed?MenuStore.getIngredients(this,p.category):new ArrayList<>();
        ArrayList<String> ingredients=new ArrayList<>(); for(String raw:rawIngredients) ingredients.add(MenuStore.ingredientName(raw));
        final int limit=MenuStore.getIngredientLimit(this,p.category);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(10),dp(4),dp(10),0);
        TextView price=tv(money.format(p.price),16,purple,true); price.setGravity(Gravity.CENTER); box.addView(price,new LinearLayout.LayoutParams(-1,dp(34)));
        LinearLayout qrow=new LinearLayout(this); qrow.setGravity(Gravity.CENTER); Button minus=purpleButton("−"),plus=purpleButton("+"); TextView qtext=tv("1",20,dark,true); qtext.setGravity(Gravity.CENTER); qrow.addView(minus,new LinearLayout.LayoutParams(dp(58),dp(48))); qrow.addView(qtext,new LinearLayout.LayoutParams(dp(70),dp(48))); qrow.addView(plus,new LinearLayout.LayoutParams(dp(58),dp(48))); box.addView(qrow,new LinearLayout.LayoutParams(-1,dp(54)));
        minus.setOnClickListener(v->{if(qty[0]>1){qty[0]--;qtext.setText(String.valueOf(qty[0]));}}); plus.setOnClickListener(v->{qty[0]++;qtext.setText(String.valueOf(qty[0]));});

        LinearLayout ingBox=new LinearLayout(this); ingBox.setOrientation(LinearLayout.VERTICAL); TextView count=tv(limit>0?"0 de "+limit+" selecionados":"",12,purple,true);
        if(extrasAllowed && !ingredients.isEmpty()){
            TextView il=tv(limit>0?"INGREDIENTES  •  MÁXIMO "+limit:"INGREDIENTES ADICIONAIS",14,dark,true); il.setPadding(0,dp(10),0,0); box.addView(il,new LinearLayout.LayoutParams(-1,dp(34))); box.addView(count,new LinearLayout.LayoutParams(-1,dp(25)));
            for(int i=0;i<ingredients.size();i++){ CheckBox cb=new CheckBox(this); cb.setText(ingredients.get(i)+"  (+"+money.format(MenuStore.getIngredientPrice(this,p.category,ingredients.get(i)))+")"); cb.setTextSize(14); cb.setTextColor(Color.DKGRAY); cb.setOnCheckedChangeListener((button,ok)->{int sc=0;for(int j=0;j<ingBox.getChildCount();j++){View child=ingBox.getChildAt(j);if(child instanceof CheckBox && ((CheckBox)child).isChecked())sc++;}if(ok&&limit>0&&sc>limit){button.setChecked(false);Toast.makeText(this,"Limite de "+limit+" ingredientes.",Toast.LENGTH_SHORT).show();return;}if(limit>0)count.setText(sc+" de "+limit+" selecionados");}); ingBox.addView(cb,new LinearLayout.LayoutParams(-1,dp(40))); }
            ScrollView ingScroll=new ScrollView(this); ingScroll.addView(ingBox); box.addView(ingScroll,new LinearLayout.LayoutParams(-1,dp(Math.min(220,Math.max(70,ingredients.size()*40)))));
        }
        EditText note=null;
        if(noteAllowed){ TextView nl=tv("OBSERVAÇÃO DO ITEM",14,dark,true); nl.setPadding(0,dp(8),0,dp(4)); box.addView(nl); note=new EditText(this); note.setHint("Ex.: sem cebola, bem passado..."); note.setSingleLine(false); note.setMinLines(2); note.setBackground(shape(Color.WHITE,12)); note.setPadding(dp(10),dp(6),dp(10),dp(6)); box.addView(note,new LinearLayout.LayoutParams(-1,dp(64))); }
        final EditText finalNote=note;
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("ADICIONAR AO PEDIDO\n"+p.name).setView(box).setNegativeButton("CANCELAR",null).setPositiveButton("ADICIONAR",null).create();
        dialog.setOnShowListener(x->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(purple);dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{ArrayList<String> selectedIng=new ArrayList<>();if(extrasAllowed){for(int i=0;i<ingredients.size();i++){View child=ingBox.getChildAt(i);if(child instanceof CheckBox&&((CheckBox)child).isChecked())selectedIng.add(ingredients.get(i));}}if(limit>0&&selectedIng.size()>limit){Toast.makeText(this,"Selecione no máximo "+limit+" ingredientes.",Toast.LENGTH_SHORT).show();return;}String n=finalNote==null?"":finalNote.getText().toString().trim();CartItem found=null;for(CartItem ci:cart)if(ci.sameConfiguration(p,n,selectedIng)){found=ci;break;}if(found==null)cart.add(new CartItem(p,qty[0],n,selectedIng));else found.quantity+=qty[0];updateCount();dialog.dismiss();Toast.makeText(this,p.name+" adicionado",Toast.LENGTH_SHORT).show();});}); dialog.show();
    }

    void showSimpleProduct(Product p, boolean noteAllowed){
        final int[] qty={1}; LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(10),dp(4),dp(10),0);
        TextView price=tv(money.format(p.price),16,purple,true); price.setGravity(Gravity.CENTER); box.addView(price,new LinearLayout.LayoutParams(-1,dp(34)));
        LinearLayout qrow=new LinearLayout(this); qrow.setGravity(Gravity.CENTER); Button minus=purpleButton("−"),plus=purpleButton("+"); TextView qtext=tv("1",20,dark,true); qtext.setGravity(Gravity.CENTER); qrow.addView(minus,new LinearLayout.LayoutParams(dp(58),dp(48)));qrow.addView(qtext,new LinearLayout.LayoutParams(dp(70),dp(48)));qrow.addView(plus,new LinearLayout.LayoutParams(dp(58),dp(48)));box.addView(qrow,new LinearLayout.LayoutParams(-1,dp(54)));minus.setOnClickListener(v->{if(qty[0]>1){qty[0]--;qtext.setText(""+qty[0]);}});plus.setOnClickListener(v->{qty[0]++;qtext.setText(""+qty[0]);});
        EditText note=null;if(noteAllowed){TextView nl=tv("OBSERVAÇÃO DO ITEM",14,dark,true);nl.setPadding(0,dp(10),0,dp(4));box.addView(nl);note=new EditText(this);note.setHint("Ex.: sem cebola, bem passado...");note.setMinLines(2);note.setBackground(shape(Color.WHITE,12));box.addView(note,new LinearLayout.LayoutParams(-1,dp(64)));}
        final EditText finalNote=note;AlertDialog dialog=new AlertDialog.Builder(this).setTitle("ADICIONAR AO PEDIDO\n"+p.name).setView(box).setNegativeButton("CANCELAR",null).setPositiveButton("ADICIONAR",null).create();dialog.setOnShowListener(x->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(purple);dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String n=finalNote==null?"":finalNote.getText().toString().trim();CartItem found=null;for(CartItem ci:cart)if(ci.sameConfiguration(p,n,new ArrayList<>())){found=ci;break;}if(found==null)cart.add(new CartItem(p,qty[0],n,new ArrayList<>()));else found.quantity+=qty[0];updateCount();dialog.dismiss();});});dialog.show();
    }

    String iconFor(String c){ if(c.equals("SANDUÍCHES"))return "🍔";if(c.equals("PIZZAS"))return "🍕";if(c.equals("PASTÉIS"))return "🥟";if(c.equals("PORÇÕES"))return "🍟";if(c.equals("AÇAÍ"))return "🍧";if(c.equals("CHURRASCO"))return "🥩";return "🥤"; }
    void updateCount(){ if(countText!=null){int total=0;for(CartItem x:cart)total+=x.quantity;countText.setText("🧾  "+total+" item(ns) na comanda");} }
    @Override protected void onResume(){ super.onResume(); products=MenuStore.load(this); if(productList!=null){renderCategories();render();} }
}
