package com.miguellanches.comanda;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class OrderActivity extends Activity {
    public static ArrayList<CartItem> cart=new ArrayList<>();
    LinearLayout list;
    TextView total;
    EditText customer,phone,address,ref,obs,delivery;
    Spinner payment,status;
    double cashReceived=0.0, changeDue=0.0;
    boolean suppressPaymentDialog=false;
    ArrayList<Client> clients=new ArrayList<>();
    static class HistoryOrder { int number; String customer,phone,status; double total; HistoryOrder(int n,String c,String p,double t,String s){number=n;customer=c;phone=p;total=t;status=s;} }
    ArrayList<HistoryOrder> orders=new ArrayList<>();
    static class Client {
        String name,phone,address,ref;
        Client(String n,String p,String a,String r){name=n;phone=p;address=a;ref=r;}
    }
    int purple=Color.rgb(91,45,179),dark=Color.rgb(45,24,91),bg=Color.rgb(247,245,251);
    int dp(float v){return(int)(v*getResources().getDisplayMetrics().density+0.5f);}
    TextView tv(String s,float z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);t.setTypeface(Typeface.DEFAULT,b?Typeface.BOLD:Typeface.NORMAL);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    GradientDrawable shape(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(shape(purple,14));b.setPadding(dp(3),0,dp(3),0);return b;}

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        loadClients();
        loadOrders();
        build();
    }
    TextView label(String s){TextView t=tv(s,12,Color.DKGRAY,true);t.setPadding(dp(2),dp(7),0,0);return t;}
    void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
        TextView bar=tv("‹  COMANDA",20,Color.WHITE,true);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(10),0,0,0);bar.setBackgroundColor(purple);bar.setOnClickListener(v->finish());root.addView(bar,new LinearLayout.LayoutParams(-1,dp(58)));
        ScrollView sv=new ScrollView(this);LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(12),dp(10),dp(12),dp(115));
        TextView title=tv("🧾  RESUMO DO PEDIDO",21,Color.BLACK,true);title.setGravity(Gravity.CENTER);content.addView(title,new LinearLayout.LayoutParams(-1,dp(42)));
        customer=field("Cliente");
        phone=field("WhatsApp / Telefone");
        address=field("Endereço");
        ref=field("Referência");
        obs=field("Observações");
        delivery=field("Taxa de entrega (R$)");
        phone.setInputType(2);
        addField(content,"CLIENTE",customer);
        addField(content,"WHATSAPP / TELEFONE",phone);
        Button findClient=button("🔎 BUSCAR CLIENTE");
        content.addView(findClient,new LinearLayout.LayoutParams(-1,dp(44)));
        findClient.setOnClickListener(v->showClientSearch());
        customer.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){
                String q=s.toString().trim();
                if(q.isEmpty()) return;
                ArrayList<Client> exact=new ArrayList<>();
                for(Client cl:clients) if(cl.name.equalsIgnoreCase(q)) exact.add(cl);
                if(exact.size()==1){
                    Client cl=exact.get(0);
                    phone.setText(cl.phone);
                    address.setText(cl.address);
                    ref.setText(cl.ref);
                }
            }
            public void afterTextChanged(android.text.Editable e){}
        });
        addField(content,"ENDEREÇO",address);addField(content,"REFERÊNCIA",ref);addField(content,"OBSERVAÇÕES",obs);addField(content,"TAXA DE ENTREGA",delivery);delivery.setInputType(2|8192);
        LinearLayout selects=new LinearLayout(this);selects.setGravity(Gravity.CENTER_VERTICAL);selects.setPadding(0,dp(4),0,dp(4));payment=new Spinner(this);status=new Spinner(this);setSpinner(payment,new String[]{"PIX","DINHEIRO","CARTÃO"});setSpinner(status,new String[]{"PAGO","PENDENTE"}); payment.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){ public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,android.view.View v,int pos,long id){ if(suppressPaymentDialog) return; if(pos==1) showCashDialog(); }});selects.addView(payment,new LinearLayout.LayoutParams(0,dp(52),1));selects.addView(status,new LinearLayout.LayoutParams(0,dp(52),1));content.addView(selects);
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        total=tv("",19,purple,true);total.setGravity(Gravity.RIGHT);content.addView(total,new LinearLayout.LayoutParams(-1,dp(60)));
        sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bottom=new LinearLayout(this);bottom.setPadding(dp(7),dp(6),dp(7),dp(6));bottom.setBackgroundColor(Color.WHITE);Button clear=button("LIMPAR"),share=button("COMPARTILHAR"),print=button("🖨  IMPRIMIR");bottom.addView(clear,new LinearLayout.LayoutParams(0,dp(52),1));bottom.addView(share,new LinearLayout.LayoutParams(0,dp(52),1));bottom.addView(print,new LinearLayout.LayoutParams(0,dp(52),1));
        clear.setOnClickListener(v->clearAll());share.setOnClickListener(v->{Intent s=new Intent(Intent.ACTION_SEND);s.setType("text/plain");s.putExtra(Intent.EXTRA_TEXT,receipt());startActivity(Intent.createChooser(s,"Compartilhar comanda"));});print.setOnClickListener(v->doPrint());

        Button finalize=button("✅ FINALIZAR PEDIDO");
        content.addView(finalize,new LinearLayout.LayoutParams(-1,dp(50)));
        finalize.setOnClickListener(v->finalizeOrder());
        Button ordersBtn=button("📋 VER PEDIDOS");
        ordersBtn.setOnClickListener(v->showOrdersPage());
        content.addView(ordersBtn,new LinearLayout.LayoutParams(-1,dp(50)));
        root.addView(bottom);setContentView(root);render();
    }
    EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setTextSize(14);e.setPadding(dp(10),0,dp(10),0);e.setBackground(shape(Color.WHITE,12));return e;}
    void addField(LinearLayout c,String label,EditText e){c.addView(label(label));c.addView(e,new LinearLayout.LayoutParams(-1,dp(48)));}
    void setSpinner(Spinner s,String[] vals){ArrayAdapter<String>a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,vals);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(a);}

    void render(){
        list.removeAllViews();double sub=0;
        for(int i=0;i<cart.size();i++){
            CartItem item=cart.get(i); if(item.quantity<=0)continue; sub+=(item.product.price+extraTotal(item))*item.quantity;
            final int idx=i;
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(10),dp(5),dp(6),dp(5));row.setBackground(shape(Color.WHITE,12));
            LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
            TextView n=tv(item.quantity+"x  "+item.product.name,14,Color.DKGRAY,true);TextView pr=tv(String.format(Locale.US,"R$ %.2f",(item.product.price+extraTotal(item))*item.quantity).replace('.',','),14,purple,true);pr.setGravity(Gravity.CENTER);
            Button minus=button("−"), plus=button("+");minus.setTextSize(17);plus.setTextSize(17);
            top.addView(n,new LinearLayout.LayoutParams(0,dp(46),1));top.addView(pr,new LinearLayout.LayoutParams(dp(94),dp(46)));top.addView(minus,new LinearLayout.LayoutParams(dp(42),dp(44)));top.addView(plus,new LinearLayout.LayoutParams(dp(42),dp(44)));
            row.addView(top);
            if(!item.extras.isEmpty()) row.addView(tv("+ "+join(item.extras,", "),11,purple,false),new LinearLayout.LayoutParams(-1,dp(24)));
            if(!item.note.isEmpty()) row.addView(tv("Obs.: "+item.note,11,Color.GRAY,false),new LinearLayout.LayoutParams(-1,dp(24)));
            minus.setOnClickListener(v->{item.quantity--;if(item.quantity<=0)cart.remove(idx);render();});
            plus.setOnClickListener(v->{item.quantity++;render();});
            row.setOnClickListener(v->editItem(idx));
            list.addView(row,new LinearLayout.LayoutParams(-1,item.extras.isEmpty()&&item.note.isEmpty()?dp(58):dp(88)));Space sp=new Space(this);list.addView(sp,new LinearLayout.LayoutParams(1,dp(5)));
        }
        double fee=num(delivery);total.setText(String.format(Locale.US,"SUBTOTAL: R$ %.2f\nTOTAL: R$ %.2f",sub,sub+fee).replace('.',','));
    }

    String join(List<String> a,String sep){StringBuilder b=new StringBuilder();for(int i=0;i<a.size();i++){if(i>0)b.append(sep);b.append(a.get(i));}return b.toString();}
    void editItem(int index){
        if(index<0||index>=cart.size())return;CartItem item=cart.get(index);Product p=item.product;ArrayList<String> rawIngredients=MenuStore.getIngredients(this,p.category);ArrayList<String> ingredients=new ArrayList<>();for(String raw:rawIngredients)ingredients.add(MenuStore.ingredientName(raw));boolean[] checked=new boolean[ingredients.size()];for(int i=0;i<ingredients.size();i++)checked[i]=item.extras.contains(ingredients.get(i));
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(10),0,dp(10),0);
        TextView qlabel=tv("QUANTIDADE",13,dark,true);box.addView(qlabel,new LinearLayout.LayoutParams(-1,dp(30)));
        LinearLayout qr=new LinearLayout(this);qr.setGravity(Gravity.CENTER);Button minus=button("−"),plus=button("+");TextView q=tv(String.valueOf(item.quantity),20,dark,true);q.setGravity(Gravity.CENTER);qr.addView(minus,new LinearLayout.LayoutParams(dp(58),dp(46)));qr.addView(q,new LinearLayout.LayoutParams(dp(70),dp(46)));qr.addView(plus,new LinearLayout.LayoutParams(dp(58),dp(46)));box.addView(qr,new LinearLayout.LayoutParams(-1,dp(50)));minus.setOnClickListener(v->{if(item.quantity>1){item.quantity--;q.setText(String.valueOf(item.quantity));}});plus.setOnClickListener(v->{item.quantity++;q.setText(String.valueOf(item.quantity));});
        TextView il=tv("INGREDIENTES ADICIONAIS",13,dark,true);box.addView(il,new LinearLayout.LayoutParams(-1,dp(34)));LinearLayout ib=new LinearLayout(this);ib.setOrientation(LinearLayout.VERTICAL);for(int i=0;i<ingredients.size();i++){CheckBox cb=new CheckBox(this);cb.setText(ingredients.get(i)+"  (+"+String.format(Locale.US,"R$ %.2f",MenuStore.getIngredientPrice(this,p.category,ingredients.get(i))).replace('.',',')+")");cb.setTextSize(13);cb.setChecked(checked[i]);final int z=i;cb.setOnCheckedChangeListener((v,on)->checked[z]=on);ib.addView(cb,new LinearLayout.LayoutParams(-1,dp(38)));}ScrollView is=new ScrollView(this);is.addView(ib);box.addView(is,new LinearLayout.LayoutParams(-1,dp(Math.min(190,Math.max(70,ingredients.size()*38)))));
        EditText note=new EditText(this);note.setHint("Observação deste item");note.setText(item.note);note.setMinLines(2);note.setBackground(shape(Color.WHITE,12));box.addView(note,new LinearLayout.LayoutParams(-1,dp(62)));
        AlertDialog d=new AlertDialog.Builder(this).setTitle("EDITAR ITEM\n"+p.name).setView(box).setNegativeButton("CANCELAR",null).setPositiveButton("SALVAR",null).create();d.setOnShowListener(x->{d.getButton(-1).setTextColor(purple);d.getButton(-1).setOnClickListener(v->{item.extras.clear();for(int i=0;i<ingredients.size();i++)if(checked[i])item.extras.add(ingredients.get(i));item.note=note.getText().toString().trim();d.dismiss();render();});});d.show();
    }
    void loadClients(){
        clients.clear();
        String raw=getPreferences(0).getString("clients_json","[]");
        try{
            JSONArray a=new JSONArray(raw);
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);
                clients.add(new Client(
                    o.optString("name"),
                    o.optString("phone"),
                    o.optString("address"),
                    o.optString("ref")
                ));
            }
        }catch(Exception e){}
    }

    void saveClients(){
        try{
            JSONArray a=new JSONArray();
            for(Client c:clients){
                JSONObject o=new JSONObject();
                o.put("name",c.name); o.put("phone",c.phone);
                o.put("address",c.address); o.put("ref",c.ref);
                a.put(o);
            }
            getPreferences(0).edit().putString("clients_json",a.toString()).apply();
        }catch(Exception e){}
    }

    void saveCurrentClient(){
        String name=customer.getText().toString().trim();
        String ph=phone.getText().toString().trim();
        if(name.isEmpty() || ph.isEmpty()) return;

        // The customer's name is the unique key.
        // If the same name already exists, update that record with the new
        // phone/address/reference instead of creating a second João.
        Client exact=null;
        for(Client c:clients){
            if(c.name.trim().equalsIgnoreCase(name)){
                exact=c;
                break;
            }
        }

        if(exact!=null){
            exact.name=name;
            exact.phone=ph;
            exact.address=address.getText().toString().trim();
            exact.ref=ref.getText().toString().trim();
        }else{
            clients.add(new Client(
                name,
                ph,
                address.getText().toString().trim(),
                ref.getText().toString().trim()
            ));
        }
        saveClients();
    }


    void showClientSearch(){
        String q=customer.getText().toString().trim().toLowerCase(Locale.ROOT);
        ArrayList<Client> matches=new ArrayList<>();
        for(Client c:clients){
            if(q.isEmpty() || c.name.toLowerCase(Locale.ROOT).contains(q)) matches.add(c);
        }
        if(matches.isEmpty()){
            Toast.makeText(this,"Nenhum cliente salvo com esse nome.",Toast.LENGTH_SHORT).show();
            return;
        }
        String[] labels=new String[matches.size()];
        for(int i=0;i<matches.size();i++){
            Client c=matches.get(i);
            labels[i]=c.name+"\\n📱 "+c.phone+"\\n🏠 "+c.address;
        }
        new AlertDialog.Builder(this)
            .setTitle("SELECIONE O CLIENTE")
            .setItems(labels,(d,which)->{
                Client c=matches.get(which);
                customer.setText(c.name);
                phone.setText(c.phone);
                address.setText(c.address);
                ref.setText(c.ref);
            })
            .setNegativeButton("CANCELAR",null)
            .show();
    }

    String orderItemsSummary(){
        StringBuilder sb=new StringBuilder();
        try{
            for(Object obj:cart){
                String line=String.valueOf(obj);
                if(sb.length()>0) sb.append("\n");
                sb.append(line);
            }
        }catch(Exception ignored){}
        if(sb.length()==0){
            try{
                if(cart!=null) sb.append(cart.toString());
            }catch(Exception ignored){}
        }
        return sb.toString();
    }

    void saveOrders(){
        try{
            JSONArray a=new JSONArray();
            for(HistoryOrder o:orders){
                JSONObject x=new JSONObject();
                x.put("number",o.number);
                x.put("customer",o.customer);
                x.put("phone",o.phone);
                x.put("total",o.total);
                x.put("status",o.status);
                x.put("items",o.items==null?"":o.items);
                x.put("observations",o.observations==null?"":o.observations);
                a.put(x);
            }
            getPreferences(0).edit().putString("orders_json",a.toString()).apply();
        }catch(Exception e){}
    }

    void loadOrders(){
        orders.clear();
        String raw=getPreferences(0).getString("orders_json","[]");
        try{
            JSONArray a=new JSONArray(raw);
            for(int i=0;i<a.length();i++){
                JSONObject x=a.getJSONObject(i);
                orders.add(new HistoryOrder(
                    x.optInt("number",1),
                    x.optString("customer",""),
                    x.optString("phone",""),
                    x.optDouble("total",0.0),
                    x.optString("status","PREPARANDO"),
                    x.optString("items",""),
                    x.optString("observations","")
                ));
            }
        }catch(Exception e){}
    }

    void showOrderDetails(final HistoryOrder o){
        root=makeRoot();
        root.addView(bar("PEDIDO #"+String.format(Locale.US,"%03d",o.number),true));

        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14),dp(12),dp(14),dp(80));

        TextView title=new TextView(this);
        title.setText("📋 PEDIDO #"+String.format(Locale.US,"%03d",o.number)+"\n👤 "+(o.customer.isEmpty()?"Cliente":o.customer));
        title.setTextSize(22); title.setTypeface(null,Typeface.BOLD);
        box.addView(title);

        TextView status=new TextView(this);
        status.setText(o.status.equals("PREPARANDO")?"🟡 PREPARANDO":"🛵 SAIU PARA ENTREGA");
        status.setTextSize(18); status.setPadding(0,dp(10),0,dp(12));
        box.addView(status);

        TextView itemsTitle=new TextView(this);
        itemsTitle.setText("ITENS DO PEDIDO");
        itemsTitle.setTextSize(18); itemsTitle.setTypeface(null,Typeface.BOLD);
        box.addView(itemsTitle);

        TextView items=new TextView(this);
        items.setText((o.items==null||o.items.trim().isEmpty())?"Itens do pedido não disponíveis.":o.items);
        items.setTextSize(17); items.setPadding(dp(8),dp(8),dp(8),dp(12));
        box.addView(items);

        if(o.observations!=null && !o.observations.trim().isEmpty()){
            TextView obsTitle=new TextView(this);
            obsTitle.setText("OBSERVAÇÕES");
            obsTitle.setTextSize(17); obsTitle.setTypeface(null,Typeface.BOLD);
            box.addView(obsTitle);
            TextView obs=new TextView(this);
            obs.setText(o.observations); obs.setTextSize(16);
            obs.setPadding(dp(8),dp(6),dp(8),dp(12)); box.addView(obs);
        }

        TextView totalView=new TextView(this);
        totalView.setText(String.format(Locale.US,"TOTAL DO PEDIDO\nR$ %.2f",o.total).replace(".",","));
        totalView.setTextSize(23); totalView.setTypeface(null,Typeface.BOLD);
        totalView.setGravity(Gravity.CENTER); totalView.setPadding(0,dp(16),0,dp(18));
        box.addView(totalView);

        LinearLayout actions=new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);

        if(o.status.equals("PREPARANDO")){
            Button outBtn=button("🛵 SAIU PARA ENTREGA");
            outBtn.setOnClickListener(v->{
                o.status="SAIU"; saveOrders();
                sendWhatsApp(o.phone,"Seu pedido já está a caminho 🛵!");
                showOrderDetails(o);
            });
            actions.addView(outBtn,new LinearLayout.LayoutParams(0,-2,1));
        }

        Button doneBtn=button("✅ ENTREGUE");
        doneBtn.setOnClickListener(v->{
            sendWhatsApp(o.phone,
                "Agradecemos a preferência e esperamos te reencontrar em breve 😃!\n"+
                "_Acesse o link para não perder nenhuma promoção postada nos storys_\n"+
                "https://www.instagram.com/miguel_lanches?igsh=MTNudDdwcG0wZHR3bA==");
            orders.remove(o); saveOrders(); showOrdersPage();
        });
        actions.addView(doneBtn,new LinearLayout.LayoutParams(0,-2,1));
        box.addView(actions);

        Button back=button("← VOLTAR PARA PEDIDOS");
        back.setOnClickListener(v->showOrdersPage());
        box.addView(back);

        ScrollView scroll=new ScrollView(this); scroll.addView(box);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    void showOrdersPage(){
        root=makeRoot();
        root.addView(bar("PEDIDOS",true));

        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12),dp(10),dp(12),dp(70));

        TextView head=new TextView(this);
        head.setText("📋 PEDIDOS EM ANDAMENTO");
        head.setTextSize(24); head.setTypeface(null,Typeface.BOLD);
        head.setGravity(Gravity.CENTER); head.setPadding(0,dp(8),0,dp(12));
        box.addView(head);

        if(orders.isEmpty()){
            TextView empty=new TextView(this);
            empty.setText("Nenhum pedido em andamento.");
            empty.setTextSize(18); empty.setGravity(Gravity.CENTER);
            empty.setPadding(0,dp(25),0,dp(25)); box.addView(empty);
        }else{
            for(HistoryOrder o:new ArrayList<>(orders)){
                LinearLayout card=new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(14),dp(10),dp(14),dp(10));
                card.setBackgroundColor(Color.WHITE);

                TextView headOrder=new TextView(this);
                headOrder.setText("#"+String.format(Locale.US,"%03d",o.number)+"  •  "+(o.customer.isEmpty()?"Cliente":o.customer));
                headOrder.setTextSize(21); headOrder.setTypeface(null,Typeface.BOLD);
                headOrder.setOnClickListener(v->showOrderDetails(o));
                card.addView(headOrder);

                TextView st=new TextView(this);
                st.setText(o.status.equals("PREPARANDO")?"🟡 PREPARANDO":"🛵 SAIU PARA ENTREGA");
                st.setTextSize(17); st.setPadding(0,dp(8),0,dp(8));
                card.addView(st);

                Button delivery=button(o.status.equals("PREPARANDO")?"🛵 SAIU PARA ENTREGA":"🛵 SAIU PARA ENTREGA");
                delivery.setOnClickListener(v->{
                    o.status="SAIU"; saveOrders();
                    sendWhatsApp(o.phone,"Seu pedido já está a caminho 🛵!");
                    showOrdersPage();
                });
                card.addView(delivery);

                Button done=button("✅ ENTREGUE");
                done.setOnClickListener(v->{
                    sendWhatsApp(o.phone,
                        "Agradecemos a preferência e esperamos te reencontrar em breve 😃!\n"+
                        "_Acesse o link para não perder nenhuma promoção postada nos storys_\n"+
                        "https://www.instagram.com/miguel_lanches?igsh=MTNudDdwcG0wZHR3bA==");
                    orders.remove(o); saveOrders(); showOrdersPage();
                });
                card.addView(done);

                box.addView(card,new LinearLayout.LayoutParams(-1,-2));
                View sp=new View(this); box.addView(sp,new LinearLayout.LayoutParams(1,dp(10)));
            }
        }

        Button back=button("← VOLTAR PARA NOVO PEDIDO");
        back.setOnClickListener(v->build()); box.addView(back);

        ScrollView scroll=new ScrollView(this); scroll.addView(box);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }





    void sendWhatsApp(String raw,String message){
        String digits=raw==null?"":raw.replaceAll("\\D","");
        if(digits.isEmpty()){
            Toast.makeText(this,"Cliente sem WhatsApp cadastrado.",Toast.LENGTH_LONG).show();
            return;
        }
        try{
            Intent i=new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse("https://wa.me/"+digits+"?text="+Uri.encode(message)));
            startActivity(i);
        }catch(Exception e){
            Toast.makeText(this,"Não foi possível abrir o WhatsApp.",Toast.LENGTH_LONG).show();
        }
    }

    void clearAll(){cart.clear();customer.setText("");phone.setText("");address.setText("");ref.setText("");obs.setText("");delivery.setText("");cashReceived=0.0;changeDue=0.0;suppressPaymentDialog=true;payment.setSelection(0);suppressPaymentDialog=false;status.setSelection(0);render();Toast.makeText(this,"Comanda e campos limpos.",Toast.LENGTH_SHORT).show();}
    void showCashDialog(){
        double sub=0.0;
        for(CartItem x:cart) sub+=(x.product.price+extraTotal(x))*x.quantity;
        double fee=num(delivery);
        final double totalToPay=sub+fee;

        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20),dp(4),dp(20),dp(4));

        TextView totalLabel=tv(String.format(Locale.US,"TOTAL A PAGAR: R$ %.2f",totalToPay).replace('.',','),18,purple,true);
        totalLabel.setGravity(Gravity.CENTER);
        box.addView(totalLabel,new LinearLayout.LayoutParams(-1,dp(48)));

        TextView receivedLabel=tv("VALOR RECEBIDO",13,dark,true);
        box.addView(receivedLabel,new LinearLayout.LayoutParams(-1,dp(30)));

        EditText received=new EditText(this);
        received.setHint("Digite o valor recebido");
        received.setTextSize(18);
        received.setInputType(2|8192);
        received.setSingleLine(true);
        received.setBackground(shape(Color.WHITE,12));
        box.addView(received,new LinearLayout.LayoutParams(-1,dp(52)));

        TextView result=tv("TROCO: R$ 0,00",19,purple,true);
        result.setGravity(Gravity.CENTER);
        box.addView(result,new LinearLayout.LayoutParams(-1,dp(54)));

        received.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){
                double value=0.0;
                try{ value=Double.parseDouble(s.toString().replace(",",".")); }catch(Exception e){}
                double diff=value-totalToPay;
                if(diff>=0){
                    result.setText(String.format(Locale.US,"TROCO: R$ %.2f",diff).replace('.',','));
                    result.setTextColor(purple);
                }else{
                    result.setText(String.format(Locale.US,"FALTA: R$ %.2f",Math.abs(diff)).replace('.',','));
                    result.setTextColor(Color.RED);
                }
            }
            public void afterTextChanged(android.text.Editable e){}
        });

        final AlertDialog dialog=new AlertDialog.Builder(this)
            .setTitle("PAGAMENTO EM DINHEIRO")
            .setView(box)
            .setNegativeButton("CANCELAR",null)
            .setPositiveButton("CONFIRMAR",null)
            .create();

        dialog.setOnShowListener(x->{
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(purple);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                double value=0.0;
                try{ value=Double.parseDouble(received.getText().toString().replace(",",".")); }catch(Exception e){}
                if(value<totalToPay){
                    Toast.makeText(this,String.format(Locale.US,"Valor insuficiente. Falta R$ %.2f",totalToPay-value).replace('.',','),Toast.LENGTH_LONG).show();
                    return;
                }
                cashReceived=value;
                changeDue=value-totalToPay;
                dialog.dismiss();
                Toast.makeText(this,String.format(Locale.US,"Troco: R$ %.2f",changeDue).replace('.',','),Toast.LENGTH_SHORT).show();
                render();
            });
            dialog.setOnDismissListener(d->{
                if(cashReceived<=0.0){
                    suppressPaymentDialog=true;
                    payment.setSelection(0);
                    suppressPaymentDialog=false;
                }
            });
        });
        dialog.show();
    }

    double num(EditText e){try{return Double.parseDouble(e.getText().toString().replace(",","."));}catch(Exception x){return 0;}}
    String fit(String s){s=s==null?"":s.replace("\r","").replace("\n"," ");if(s.length()>32)return s.substring(0,32);StringBuilder b=new StringBuilder(s);while(b.length()<32)b.append(' ');return b.toString();}
    String right(String label,double value){String val=String.format(Locale.US,"R$ %.2f",value).replace('.',',');int spaces=32-label.length()-val.length();if(spaces<1)spaces=1;return fit(label+repeat(' ',spaces)+val);}
    String repeat(char c,int n){StringBuilder b=new StringBuilder();for(int i=0;i<n;i++)b.append(c);return b.toString();}
    String itemLine(CartItem item){String q=item.quantity+"x";String name=item.product.name==null?"":item.product.name.toUpperCase(Locale.ROOT);if(name.length()>19)name=name.substring(0,19);String val=String.format(Locale.US,"%.2f",(item.product.price+extraTotal(item))*item.quantity).replace('.',',');int spaces=32-q.length()-2-name.length()-val.length();if(spaces<1)spaces=1;return fit(q+"  "+name+repeat(' ',spaces)+val);}
    double extraTotal(CartItem item){ double total=0; for(String e:item.extras) total+=MenuStore.getIngredientPrice(this,item.product.category,e); return total; }
    String extraLine(String name,double price){ return fit("  + "+name+"  +R$ "+String.format(Locale.US,"%.2f",price).replace('.',',')); }
    String receipt(){Calendar now=Calendar.getInstance();String date=new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(now.getTime());String time=new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(now.getTime());int no=getPreferences(0).getInt("order",1);double sub=0;for(CartItem x:cart)sub+=(x.product.price+extraTotal(x))*x.quantity;double fee=num(delivery),totalV=sub+fee;StringBuilder s=new StringBuilder();s.append("================================\n");s.append(fit("         MIGUEL LANCHES")+"\n");s.append(fit("   Hamburgueria e Pizzaria")+"\n");s.append("================================\n");String hm=time.substring(0,5); s.append(fit("Data: "+date+"   Hora: "+hm)+"\n");s.append(fit("Pedido: #"+String.format(Locale.US,"%03d",no))+"\n");s.append("--------------------------------\n");s.append(fit("QTD ITEM                 VALOR")+"\n");s.append("--------------------------------\n");for(CartItem x:cart){s.append(itemLine(x)+"\n");for(String e:x.extras)s.append(extraLine(e,MenuStore.getIngredientPrice(this,x.product.category,e))+"\n");if(!x.note.isEmpty())s.append(fit("  Obs: "+x.note)+"\n");}s.append("--------------------------------\n");s.append(right("SUBTOTAL:",sub)+"\n");s.append(right("TAXA DE ENTREGA:",fee)+"\n");s.append("--------------------------------\n");s.append(right("TOTAL:",totalV)+"\n");s.append("--------------------------------\n");s.append(fit("FORMA DE PAGAMENTO: "+payment.getSelectedItem().toString())+"\n");if(payment.getSelectedItem().toString().equals("DINHEIRO") && cashReceived>0.0){s.append(fit(String.format(Locale.US,"VALOR RECEBIDO: R$ %.2f",cashReceived).replace('.',','))+"\n");s.append(fit(String.format(Locale.US,"TROCO: R$ %.2f",changeDue).replace('.',','))+"\n");}s.append(fit("STATUS: "+status.getSelectedItem().toString())+"\n");s.append("--------------------------------\n");s.append(fit("CLIENTE: "+customer.getText().toString())+"\n");s.append(fit("ENDERECO: "+address.getText().toString())+"\n");s.append(fit("REF: "+ref.getText().toString())+"\n");s.append(fit("OBS: "+obs.getText().toString())+"\n");s.append("================================\n");s.append(fit("    Obrigado pela preferencia!")+"\n");s.append("================================\n");return s.toString();}
    void notifyOrderReceived(){
        String name=customer.getText().toString().trim();
        String rawPhone=phone.getText().toString().trim();
        String digits=rawPhone.replaceAll("\\D","");
        if(digits.isEmpty()) return;

        String firstName=name.isEmpty() ? "cliente" : name;
        String msg="Olá, "+firstName+"! 👋\n\n"+
                "Recebemos seu pedido na Miguel Lanches e ele já será preparado. 🍔🍕\n\n"+
                "⏱️ O prazo estimado para preparo e entrega é de 40 a 90 minutos, "+
                "podendo variar conforme o movimento e a distância.\n\n"+
                "Assim que estiver a caminho, avisaremos você. 🛵\n\n"+
                "Obrigado pela preferência! 💜\n"+
                "— Miguel Lanches";

        try{
            Intent i=new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse("https://wa.me/"+digits+"?text="+Uri.encode(msg)));
            startActivity(i);
        }catch(Exception e){
            Toast.makeText(this,"Não foi possível abrir o WhatsApp.",Toast.LENGTH_LONG).show();
        }
    }

    void finalizeOrder(){
        if(cart==null || cart.isEmpty()){
            Toast.makeText(this,"Adicione pelo menos um produto.",Toast.LENGTH_SHORT).show();
            return;
        }

        // Capture data before clearing the form.
        final String name = customer==null ? "" : customer.getText().toString().trim();
        final String digits = phone==null ? "" : phone.getText().toString().trim().replaceAll("\\D","");
        final String addr = address==null ? "" : address.getText().toString().trim();
        final String reference = ref==null ? "" : ref.getText().toString().trim();

        // Save customer without allowing a save error to close the app.
        try{
            saveCurrentClient();
        }catch(Exception ignored){}

        // Save order in "PREPARANDO" before clearing the comanda.
        try{
            int orderNo=getPreferences(0).getInt("order",1);
            double orderTotal=0.0;
            try{
                if(total!=null){
                    String s=total.getText().toString().replace("R$","").trim();
                    if(s.contains(",") && s.contains(".")){
                        s=s.replace(".","").replace(",",".");
                    }else{
                        s=s.replace(",",".");
                    }
                    orderTotal=Double.parseDouble(s);
                }
            }catch(Exception ignored){}
            String itemSummary=orderItemsSummary();
            String obsText=observations==null?"":observations.getText().toString().trim();
            orders.add(new HistoryOrder(orderNo,name,digits,orderTotal,"PREPARANDO",itemSummary,obsText));
            saveOrders();
        }catch(Exception ignored){}

        // Try to print, but never close the app if the printer fails.
        try{
            doPrint();
        }catch(Exception e){
            Toast.makeText(this,"Pedido salvo, mas houve um erro ao imprimir.",Toast.LENGTH_LONG).show();
        }

        // Clear all current order/editable fields.
        try{
            clearAll();
        }catch(Exception ignored){}

        // WhatsApp is optional; failures must not close the app.
        if(!digits.isEmpty()){
            String msg="Vim aqui te dizer que *já estamos preparando* o seu pedido 🚀\n"+
                    "Tempo estimado é de 40 - 90 minutos!";
            try{
                Intent i=new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse("https://wa.me/"+digits+"?text="+Uri.encode(msg)));
                startActivity(i);
            }catch(Exception e){
                Toast.makeText(this,"Pedido finalizado. Não foi possível abrir o WhatsApp.",Toast.LENGTH_LONG).show();
            }
        }

        // Return to the order screen/history without terminating the activity.
        try{
            build();
        }catch(Exception ignored){}
    }


    void doPrint(){if(cart.isEmpty()){Toast.makeText(this,"Adicione pelo menos um produto.",Toast.LENGTH_SHORT).show();return;}saveCurrentClient();BluetoothPrinter.print(this,receipt(),(ok,msg)->{Toast.makeText(this,msg,Toast.LENGTH_LONG).show();if(ok){
                    int n=getPreferences(0).getInt("order",1);
                    getPreferences(0).edit().putInt("order",n+1).apply();
                    notifyOrderReceived();
                }});}
}
