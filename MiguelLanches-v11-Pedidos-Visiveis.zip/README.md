Miguel Lanches v12
- Tela separada PEDIDOS.
- Finalizar Pedido salva o pedido e retorna à comanda para novos pedidos.
- Pedidos ficam na tela PEDIDOS até ENTREGUE.
- SAIU PARA ENTREGA mantém o pedido na lista.
- ENTREGUE envia a mensagem final e remove somente aquele pedido.
- Os outros pedidos permanecem.
