Miguel Lanches v11 - Finalizar Pedido corrigido.

Correções:
- Finalizar Pedido captura os dados antes de limpar.
- Salva o pedido como PREPARANDO.
- Tenta imprimir sem deixar erro da impressora fechar o app.
- Limpa os campos da comanda.
- Tenta abrir o WhatsApp somente depois.
- Falha no WhatsApp não fecha o aplicativo.
- Retorna para a tela de Pedidos em Andamento.
