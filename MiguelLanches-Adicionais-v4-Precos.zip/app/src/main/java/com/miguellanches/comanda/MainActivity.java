package com.miguellanches.comanda;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    LinearLayout productList, categories;
    HorizontalScrollView categoryScroll;
    TextView categoryTitle, countText;
    String selected = "PIZZAS";
    ArrayList<Product> products;
    public static ArrayList<CartItem> cart = new ArrayList<>();
    NumberFormat money = NumberFormat.getCurrencyInstance(new Locale("pt","BR"));
    int purple=Color.rgb(91,45,179), dark=Color.rgb(45,24,91), bg=Color.rgb(247,245,251);

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        products=MenuStore.load(this);
        build();
    }

    TextView tv(String s,float size,int color,boolean bold){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    GradientDrawable shape(int color,float radius){
        GradientDrawable g=new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius));
        return g;
    }

    TextView chip(String text, boolean active){
        TextView t=tv(text,12,active?Color.WHITE:dark,true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(4),0,dp(4),0);
        t.setBackground(shape(active?purple:Color.WHITE,18));
        return t;
    }

    Button purpleButton(String s){
        Button b=new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        b.setTextSize(13); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setBackground(shape(purple,16));
        b.setPadding(dp(4),0,dp(4),0);
        return b;
    }

    void build(){
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);

        LinearLayout bar=new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(12),0,dp(8),0);
        bar.setBackgroundColor(purple);
        TextView menu=tv("☰",28,Color.WHITE,false);
        bar.addView(menu,new LinearLayout.LayoutParams(dp(42),dp(58)));
        TextView title=tv("NOVO PEDIDO",20,Color.WHITE,true);
        bar.addView(title,new LinearLayout.LayoutParams(0,dp(58),1));
        TextView edit=tv("⚙",24,Color.WHITE,false);
        edit.setGravity(Gravity.CENTER);
        bar.addView(edit,new LinearLayout.LayoutParams(dp(46),dp(58)));
        edit.setOnClickListener(v->startActivity(new Intent(this,AdminActivity.class)));
        root.addView(bar);

        LinearLayout intro=new LinearLayout(this);
        intro.setOrientation(LinearLayout.VERTICAL);
        intro.setGravity(Gravity.CENTER);
        intro.setPadding(dp(10),dp(8),dp(10),dp(2));
        TextView h=tv("🧾  NOVO PEDIDO",24,Color.BLACK,true);
        h.setGravity(Gravity.CENTER);
        intro.addView(h,new LinearLayout.LayoutParams(-1,dp(38)));
        TextView hint=tv("Escolha uma categoria e toque no produto para adicionar à comanda",13,Color.DKGRAY,false);
        hint.setGravity(Gravity.CENTER);
        intro.addView(hint,new LinearLayout.LayoutParams(-1,dp(38)));
        root.addView(intro);

        categoryScroll=new HorizontalScrollView(this);
        categoryScroll.setHorizontalScrollBarEnabled(false);
        categoryScroll.setFillViewport(false);
        categories=new LinearLayout(this);
        categories.setGravity(Gravity.CENTER_VERTICAL);
        categories.setPadding(dp(10),dp(5),dp(10),dp(9));
        categoryScroll.addView(categories);
        root.addView(categoryScroll,new LinearLayout.LayoutParams(-1,dp(64)));
        renderCategories();

        categoryTitle=tv("",20,dark,true);
        categoryTitle.setGravity(Gravity.CENTER);
        root.addView(categoryTitle,new LinearLayout.LayoutParams(-1,dp(48)));

        ScrollView sv=new ScrollView(this);
        productList=new LinearLayout(this);
        productList.setOrientation(LinearLayout.VERTICAL);
        productList.setPadding(dp(12),dp(4),dp(12),dp(95));
        sv.addView(productList);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout bottom=new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setPadding(dp(12),dp(7),dp(12),dp(7));
        bottom.setBackgroundColor(Color.WHITE);
        countText=tv("🧾 0 item(ns) na comanda",15,Color.DKGRAY,true);
        bottom.addView(countText,new LinearLayout.LayoutParams(0,dp(58),1));
        Button view=purpleButton("🛒  VER COMANDA");
        bottom.addView(view,new LinearLayout.LayoutParams(dp(170),dp(50)));
        view.setOnClickListener(v->{
            OrderActivity.cart=cart;
            startActivity(new Intent(this,OrderActivity.class));
        });
        root.addView(bottom);

        setContentView(root);
        render();
    }

    void renderCategories(){
        categories.removeAllViews();
        String[] icons={"🍕","🥟","🥩","🍔","🍟"};
        for(int i=0;i<MenuStore.CATEGORIES.size();i++){
            String c=MenuStore.CATEGORIES.get(i);
            TextView cb=chip(icons[i]+"  "+c,c.equals(selected));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(112),dp(46));
            lp.setMargins(dp(4),0,dp(4),0);
            categories.addView(cb,lp);
            final int index=i;
            cb.setOnClickListener(v->{
                selected=c;
                renderCategories();
                render();
                cb.post(()->{
                    int left=cb.getLeft();
                    int right=cb.getRight();
                    int visible=categoryScroll.getWidth();
                    int scroll=categoryScroll.getScrollX();
                    if(left<scroll) categoryScroll.smoothScrollTo(Math.max(0,left-dp(8)),0);
                    else if(right>scroll+visible) categoryScroll.smoothScrollTo(right-visible+dp(8),0);
                });
            });
        }
        categoryScroll.post(()->{
            for(int i=0;i<categories.getChildCount();i++){
                View v=categories.getChildAt(i);
                if(v instanceof TextView && ((TextView)v).getText().toString().contains(selected)){
                    int left=v.getLeft(), right=v.getRight();
                    int visible=categoryScroll.getWidth();
                    int target=Math.max(0,(left+right-visible)/2);
                    categoryScroll.scrollTo(target,0);
                    break;
                }
            }
        });
    }

    void render(){
        if(categoryTitle==null)return;
        categoryTitle.setText(selected);
        productList.removeAllViews();

        for(Product p:products) if(p.category.equals(selected)){
            LinearLayout card=new LinearLayout(this);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(10),dp(5),dp(8),dp(5));
            card.setBackground(shape(Color.WHITE,15));

            TextView icon=tv(iconFor(p.category),25,Color.BLACK,false);
            icon.setGravity(Gravity.CENTER);
            card.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(58)));

            LinearLayout texts=new LinearLayout(this);
            texts.setOrientation(LinearLayout.VERTICAL);
            texts.setGravity(Gravity.CENTER_VERTICAL);
            TextView name=tv(p.name,15,Color.rgb(45,45,45),true);
            TextView sub=tv("Toque para adicionar",11,Color.GRAY,false);
            texts.addView(name,new LinearLayout.LayoutParams(-1,dp(31)));
            texts.addView(sub,new LinearLayout.LayoutParams(-1,dp(22)));
            card.addView(texts,new LinearLayout.LayoutParams(0,dp(68),1));

            TextView price=tv(money.format(p.price),14,purple,true);
            price.setGravity(Gravity.CENTER);
            card.addView(price,new LinearLayout.LayoutParams(dp(94),dp(68)));

            card.setOnClickListener(v->{
                showProductOptions(p);
            });

            productList.addView(card,new LinearLayout.LayoutParams(-1,dp(70)));
            Space sp=new Space(this);
            productList.addView(sp,new LinearLayout.LayoutParams(1,dp(7)));
        }
        updateCount();
    }


    void showProductOptions(Product p){
        final int[] qty={1};
        ArrayList<String> rawIngredients=MenuStore.getIngredients(this,p.category);
        ArrayList<String> ingredients=new ArrayList<>();
        for(String raw:rawIngredients) ingredients.add(MenuStore.ingredientName(raw));
        boolean[] checked=new boolean[ingredients.size()];
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10),dp(4),dp(10),0);

        TextView price=tv(money.format(p.price),16,purple,true);
        price.setGravity(Gravity.CENTER);
        box.addView(price,new LinearLayout.LayoutParams(-1,dp(34)));

        LinearLayout qrow=new LinearLayout(this);
        qrow.setGravity(Gravity.CENTER);
        Button minus=purpleButton("−"), plus=purpleButton("+");
        TextView qtext=tv("1",20,dark,true); qtext.setGravity(Gravity.CENTER);
        qrow.addView(minus,new LinearLayout.LayoutParams(dp(58),dp(48)));
        qrow.addView(qtext,new LinearLayout.LayoutParams(dp(70),dp(48)));
        qrow.addView(plus,new LinearLayout.LayoutParams(dp(58),dp(48)));
        box.addView(qrow,new LinearLayout.LayoutParams(-1,dp(54)));
        minus.setOnClickListener(v->{if(qty[0]>1){qty[0]--;qtext.setText(String.valueOf(qty[0]));}});
        plus.setOnClickListener(v->{qty[0]++;qtext.setText(String.valueOf(qty[0]));});

        TextView il=tv("INGREDIENTES ADICIONAIS",14,dark,true); il.setPadding(0,dp(10),0,0);
        box.addView(il,new LinearLayout.LayoutParams(-1,dp(34)));
        LinearLayout ingBox=new LinearLayout(this); ingBox.setOrientation(LinearLayout.VERTICAL);
        for(int i=0;i<ingredients.size();i++){
            CheckBox cb=new CheckBox(this); cb.setText(ingredients.get(i)+"  (+"+money.format(MenuStore.getIngredientPrice(this,p.category,ingredients.get(i)))+")"); cb.setTextSize(14); cb.setTextColor(Color.DKGRAY); cb.setPadding(0,0,0,0);
            final int idx=i; cb.setOnCheckedChangeListener((b,ok)->checked[idx]=ok); ingBox.addView(cb,new LinearLayout.LayoutParams(-1,dp(40)));
        }
        ScrollView ingScroll=new ScrollView(this); ingScroll.addView(ingBox);
        box.addView(ingScroll,new LinearLayout.LayoutParams(-1,dp(Math.min(220,Math.max(70,ingredients.size()*40)))));

        TextView nl=tv("OBSERVAÇÃO DO PEDIDO",14,dark,true); nl.setPadding(0,dp(8),0,dp(4)); box.addView(nl);
        EditText note=new EditText(this); note.setHint("Ex.: sem cebola, bem passado..."); note.setSingleLine(false); note.setMinLines(2); note.setBackground(shape(Color.WHITE,12)); note.setPadding(dp(10),dp(6),dp(10),dp(6));
        box.addView(note,new LinearLayout.LayoutParams(-1,dp(64)));

        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("ADICIONAR AO PEDIDO\n"+p.name).setView(box).setNegativeButton("CANCELAR",null).setPositiveButton("ADICIONAR",null).create();
        dialog.setOnShowListener(x->{
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(purple);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                ArrayList<String> selectedIng=new ArrayList<>();
                for(int i=0;i<ingredients.size();i++) if(checked[i]) selectedIng.add(ingredients.get(i));
                String n=note.getText().toString().trim();
                CartItem found=null;
                for(CartItem ci:cart) if(ci.sameConfiguration(p,n,selectedIng)){found=ci;break;}
                if(found==null) cart.add(new CartItem(p,qty[0],n,selectedIng)); else found.quantity+=qty[0];
                updateCount(); dialog.dismiss(); Toast.makeText(this,p.name+" adicionado",Toast.LENGTH_SHORT).show();
            });
        });
        dialog.show();
    }

    String iconFor(String c){
        if(c.equals("PIZZAS"))return "🍕";
        if(c.equals("PASTÉIS"))return "🥟";
        if(c.equals("CHURRASCO"))return "🥩";
        if(c.equals("SANDUÍCHES"))return "🍔";
        return "🍟";
    }

    void updateCount(){
        if(countText!=null){ int total=0; for(CartItem x:cart) total+=x.quantity; countText.setText("🧾  "+total+" item(ns) na comanda"); }
    }

    @Override protected void onResume(){
        super.onResume();
        products=MenuStore.load(this);
        if(productList!=null){ renderCategories(); render(); }
    }
}
