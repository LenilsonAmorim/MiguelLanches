package com.miguellanches.comanda;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MenuStore {
    private static final String PREF = "menu_store";
    private static final String KEY = "products";
    private static final String KEY_ING = "ingredients";

    public static final List<String> CATEGORIES = Arrays.asList(
        "PIZZAS", "PASTÉIS", "CHURRASCO", "SANDUÍCHES", "PORÇÕES"
    );

    public static ArrayList<Product> load(Context c) {
        ArrayList<Product> out = new ArrayList<>();
        String raw = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null);
        try {
            if (raw != null) {
                JSONArray a = new JSONArray(raw);
                for (int i=0;i<a.length();i++) {
                    JSONObject o = a.getJSONObject(i);
                    out.add(new Product(o.getString("category"), o.getString("name"), o.getDouble("price")));
                }
                return out;
            }
        } catch (Exception ignored) {}
        out.add(new Product("PIZZAS","Pizza Média",24.00));
        out.add(new Product("PIZZAS","Pizza Grande",34.00));
        out.add(new Product("PASTÉIS","Pastel de Carne",9.00));
        out.add(new Product("PASTÉIS","Pastel de Queijo",9.00));
        out.add(new Product("CHURRASCO","Espetinho de Carne",10.00));
        out.add(new Product("CHURRASCO","Espetinho de Frango",10.00));
        out.add(new Product("SANDUÍCHES","A Moda da Casa",24.00));
        out.add(new Product("SANDUÍCHES","X-Tudo",22.00));
        out.add(new Product("PORÇÕES","Batata Frita",16.00));
        out.add(new Product("PORÇÕES","Batata c/ Cheddar e Bacon",22.00));
        save(c, out);
        return out;
    }

    public static void save(Context c, ArrayList<Product> list) {
        try {
            JSONArray a = new JSONArray();
            for (Product p : list) {
                JSONObject o = new JSONObject();
                o.put("category", p.category);
                o.put("name", p.name);
                o.put("price", p.price);
                a.put(o);
            }
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static LinkedHashMap<String, ArrayList<String>> loadIngredients(Context c) {
        LinkedHashMap<String, ArrayList<String>> out = new LinkedHashMap<>();
        String raw = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_ING, null);
        try {
            if (raw != null) {
                JSONObject all = new JSONObject(raw);
                for (String cat : CATEGORIES) {
                    ArrayList<String> list = new ArrayList<>();
                    JSONArray a = all.optJSONArray(cat);
                    if (a != null) for (int i=0;i<a.length();i++) list.add(a.getString(i));
                    out.put(cat, list);
                }
                return out;
            }
        } catch (Exception ignored) {}
        out.put("PIZZAS", new ArrayList<>(Arrays.asList("MUSSARELA|0.00","CATUPIRY|3.00","BACON|5.00","CEBOLA|2.00","TOMATE|2.00","CHEDDAR|4.00","MILHO|2.00","OVO|3.00")));
        out.put("PASTÉIS", new ArrayList<>(Arrays.asList("QUEIJO|3.00","CARNE|0.00","FRANGO|0.00","BACON|4.00","CATUPIRY|3.00","CALABRESA|3.00","OVO|2.00")));
        out.put("CHURRASCO", new ArrayList<>(Arrays.asList("QUEIJO|3.00","BACON|4.00","CEBOLA|2.00","VINAGRETE|2.00","FAROFA|2.00","CATUPIRY|3.00")));
        out.put("SANDUÍCHES", new ArrayList<>(Arrays.asList("BACON|4.00","QUEIJO|3.00","CHEDDAR|4.00","CATUPIRY|3.00","OVO|2.00","CEBOLA|2.00","PRESUNTO|3.00","SALADA|0.00")));
        out.put("PORÇÕES", new ArrayList<>(Arrays.asList("CHEDDAR|4.00","BACON|5.00","CATUPIRY|3.00","MOLHO ESPECIAL|2.00","MOLHO DE ALHO|2.00","KETCHUP|1.00")));
        saveIngredients(c, out);
        return out;
    }

    public static ArrayList<String> getIngredients(Context c, String category) {
        return loadIngredients(c).getOrDefault(category, new ArrayList<>());
    }

    public static String ingredientName(String raw) {
        if (raw == null) return "";
        int i = raw.lastIndexOf("|");
        return i > 0 ? raw.substring(0, i) : raw;
    }

    public static double ingredientPrice(String raw) {
        if (raw == null) return 0;
        int i = raw.lastIndexOf("|");
        if (i > 0) {
            try { return Double.parseDouble(raw.substring(i + 1).replace(",", ".")); } catch (Exception ignored) {}
        }
        return 0;
    }

    public static String packIngredient(String name, double price) {
        return ingredientName(name).trim().toUpperCase(java.util.Locale.ROOT) + "|" + String.format(java.util.Locale.US, "%.2f", price);
    }

    public static ArrayList<String> getIngredientNames(Context c, String category) {
        ArrayList<String> out = new ArrayList<>();
        for (String x : getIngredients(c, category)) out.add(ingredientName(x));
        return out;
    }

    public static double getIngredientPrice(Context c, String category, String name) {
        for (String x : getIngredients(c, category)) if (ingredientName(x).equalsIgnoreCase(name)) return ingredientPrice(x);
        return 0;
    }

    public static void saveIngredients(Context c, Map<String, ArrayList<String>> data) {
        try {
            JSONObject all = new JSONObject();
            for (String cat : CATEGORIES) {
                JSONArray a = new JSONArray();
                ArrayList<String> list = data.get(cat);
                if (list != null) for (String x : list) if (x != null && !x.trim().isEmpty()) a.put(x.trim());
                all.put(cat, a);
            }
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY_ING, all.toString()).apply();
        } catch (Exception ignored) {}
    }
}
