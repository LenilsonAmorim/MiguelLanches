package com.miguellanches.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private WebView webView;
    private final Handler updateHandler = new Handler();
    private static final long UPDATE_CHECK_MS = 30000L;

    private static final String SITE =
            "https://lenilsonamorim.github.io/MiguelLanches/";

    private final Runnable updateChecker = new Runnable() {
        @Override
        public void run() {
            if (webView != null) {
                checkForSiteUpdate();
            }
            updateHandler.postDelayed(this, UPDATE_CHECK_MS);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setCacheMode(
                android.webkit.WebSettings.LOAD_NO_CACHE
        );
        webView.getSettings().setSupportMultipleWindows(false);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance()
                .setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient());

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(
                    WebView view,
                    WebResourceRequest request) {
                return tratarLink(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(
                    WebView view,
                    String url) {
                return tratarLink(url);
            }
        });

        webView.loadUrl(SITE);
        updateHandler.postDelayed(updateChecker, UPDATE_CHECK_MS);
    }

    private void checkForSiteUpdate() {
        String script =
                "(async()=>{" +
                "try{" +
                "const r=await fetch(location.href,{cache:'no-store'});" +
                "const t=await r.text();" +
                "const m=t.match(/app\\\\.js\\\\?v=([^\\\"'&]+)/);" +
                "const current=[...document.scripts].map(s=>s.src).find(x=>x.includes('app.js'))||'';" +
                "const c=current.match(/app\\\\.js\\\\?v=([^&]+)/);" +
                "if(m&&c&&m[1]!==c[1]){location.reload();}" +
                "}catch(e){}" +
                "})()";

        webView.evaluateJavascript(script, null);
    }

    private boolean tratarLink(String url) {

        // Abre somente o WhatsApp instalado no celular.
        if (url.startsWith("whatsapp://")) {
            try {
                Intent whatsapp = new Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse(url)
                );
                startActivity(whatsapp);
            } catch (ActivityNotFoundException ignored) {
            }
            return true;
        }

        // Suporte a intent:// direcionado ao WhatsApp.
        if (url.startsWith("intent://")) {
            try {
                Intent intent = Intent.parseUri(
                        url,
                        Intent.URI_INTENT_SCHEME
                );

                String pacote = intent.getPackage();

                if (pacote == null || pacote.equals("com.whatsapp")) {
                    startActivity(intent);
                }
            } catch (Exception ignored) {
            }
            return true;
        }

        // Não abrir WhatsApp Web dentro do APK.
        if (url.startsWith("https://web.whatsapp.com/")) {
            return true;
        }

        return false;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        updateHandler.removeCallbacks(updateChecker);

        if (webView != null) {
            webView.destroy();
        }

        super.onDestroy();
    }
}
