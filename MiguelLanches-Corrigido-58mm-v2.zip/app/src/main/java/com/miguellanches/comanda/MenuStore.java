package com.miguellanches.comanda;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MenuStore {
    private static final String PREF = "menu_store";
    private static final String KEY = "products";

    public static final List<String> CATEGORIES = Arrays.asList(
        "PIZZAS", "PASTÉIS", "CHURRASCO", "SANDUÍCHES", "PORÇÕES"
    );

    public static ArrayList<Product> load(Context c) {
        ArrayList<Product> out = new ArrayList<>();
        String raw = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null);
        try {
            if (raw != null) {
                JSONArray a = new JSONArray(raw);
                for (int i=0;i<a.length();i++) {
                    JSONObject o = a.getJSONObject(i);
                    out.add(new Product(o.getString("category"), o.getString("name"), o.getDouble("price")));
                }
                return out;
            }
        } catch (Exception ignored) {}
        out.add(new Product("PIZZAS","Pizza Média",24.00));
        out.add(new Product("PIZZAS","Pizza Grande",34.00));
        out.add(new Product("PASTÉIS","Pastel de Carne",9.00));
        out.add(new Product("PASTÉIS","Pastel de Queijo",9.00));
        out.add(new Product("CHURRASCO","Espetinho de Carne",10.00));
        out.add(new Product("CHURRASCO","Espetinho de Frango",10.00));
        out.add(new Product("SANDUÍCHES","A Moda da Casa",24.00));
        out.add(new Product("SANDUÍCHES","X-Tudo",22.00));
        out.add(new Product("PORÇÕES","Batata Frita",16.00));
        out.add(new Product("PORÇÕES","Batata c/ Cheddar e Bacon",22.00));
        save(c, out);
        return out;
    }

    public static void save(Context c, ArrayList<Product> list) {
        try {
            JSONArray a = new JSONArray();
            for (Product p : list) {
                JSONObject o = new JSONObject();
                o.put("category", p.category);
                o.put("name", p.name);
                o.put("price", p.price);
                a.put(o);
            }
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply();
        } catch (Exception ignored) {}
    }
}
