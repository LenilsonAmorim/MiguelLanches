package com.miguellanches.comanda;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class OrderActivity extends Activity {
    public static ArrayList<Product> cart=new ArrayList<>();
    LinearLayout list;
    TextView total;
    EditText customer,address,ref,obs,delivery;
    Spinner payment,status;
    int purple=Color.rgb(91,45,179),dark=Color.rgb(45,24,91),bg=Color.rgb(247,245,251);

    int dp(float v){return(int)(v*getResources().getDisplayMetrics().density+0.5f);}

    TextView tv(String s,float z,int c,boolean b){
        TextView t=new TextView(this);
        t.setText(s);t.setTextSize(z);t.setTextColor(c);
        t.setTypeface(Typeface.DEFAULT,b?Typeface.BOLD:Typeface.NORMAL);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    GradientDrawable shape(int c,float r){
        GradientDrawable g=new GradientDrawable();
        g.setColor(c);g.setCornerRadius(dp(r));return g;
    }

    Button button(String s){
        Button b=new Button(this);
        b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);
        b.setTextSize(12);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setBackground(shape(purple,14));b.setPadding(dp(3),0,dp(3),0);
        return b;
    }

    @Override public void onCreate(Bundle b){super.onCreate(b);build();}

    TextView label(String s){
        TextView t=tv(s,12,Color.DKGRAY,true);
        t.setPadding(dp(2),dp(7),0,0);return t;
    }

    void build(){
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);

        TextView bar=tv("‹  COMANDA",20,Color.WHITE,true);
        bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(10),0,0,0);
        bar.setBackgroundColor(purple);bar.setOnClickListener(v->finish());
        root.addView(bar,new LinearLayout.LayoutParams(-1,dp(58)));

        ScrollView sv=new ScrollView(this);
        LinearLayout content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12),dp(10),dp(12),dp(115));

        TextView title=tv("🧾  RESUMO DO PEDIDO",21,Color.BLACK,true);
        title.setGravity(Gravity.CENTER);
        content.addView(title,new LinearLayout.LayoutParams(-1,dp(42)));

        customer=field("Cliente");address=field("Endereço");ref=field("Referência");
        obs=field("Observações");delivery=field("Taxa de entrega (R$)");
        addField(content,"CLIENTE",customer);
        addField(content,"ENDEREÇO",address);
        addField(content,"REFERÊNCIA",ref);
        addField(content,"OBSERVAÇÕES",obs);
        addField(content,"TAXA DE ENTREGA",delivery);
        delivery.setInputType(2|8192);

        LinearLayout selects=new LinearLayout(this);
        selects.setGravity(Gravity.CENTER_VERTICAL);
        selects.setPadding(0,dp(4),0,dp(4));
        payment=new Spinner(this);status=new Spinner(this);
        setSpinner(payment,new String[]{"PIX","DINHEIRO","CARTÃO"});
        setSpinner(status,new String[]{"PAGO","PENDENTE"});
        selects.addView(payment,new LinearLayout.LayoutParams(0,dp(52),1));
        selects.addView(status,new LinearLayout.LayoutParams(0,dp(52),1));
        content.addView(selects);

        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        content.addView(list);

        total=tv("",19,purple,true);
        total.setGravity(Gravity.RIGHT);
        content.addView(total,new LinearLayout.LayoutParams(-1,dp(60)));

        sv.addView(content);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout bottom=new LinearLayout(this);
        bottom.setPadding(dp(7),dp(6),dp(7),dp(6));
        bottom.setBackgroundColor(Color.WHITE);
        Button clear=button("LIMPAR"),share=button("COMPARTILHAR"),print=button("🖨  IMPRIMIR");
        bottom.addView(clear,new LinearLayout.LayoutParams(0,dp(52),1));
        bottom.addView(share,new LinearLayout.LayoutParams(0,dp(52),1));
        bottom.addView(print,new LinearLayout.LayoutParams(0,dp(52),1));

        clear.setOnClickListener(v->clearAll());
        share.setOnClickListener(v->{
            Intent s=new Intent(Intent.ACTION_SEND);
            s.setType("text/plain");
            s.putExtra(Intent.EXTRA_TEXT,receipt());
            startActivity(Intent.createChooser(s,"Compartilhar comanda"));
        });
        print.setOnClickListener(v->doPrint());

        root.addView(bottom);
        setContentView(root);
        render();
    }

    EditText field(String hint){
        EditText e=new EditText(this);
        e.setHint(hint);e.setSingleLine(true);e.setTextSize(14);
        e.setPadding(dp(10),0,dp(10),0);
        e.setBackground(shape(Color.WHITE,12));
        return e;
    }

    void addField(LinearLayout c,String label,EditText e){
        c.addView(label(label));
        c.addView(e,new LinearLayout.LayoutParams(-1,dp(48)));
    }

    void setSpinner(Spinner s,String[] vals){
        ArrayAdapter<String>a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,vals);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
    }

    // Agrupa produtos iguais: 1x, 2x, 3x...
    LinkedHashMap<String,Integer> quantities(){
        LinkedHashMap<String,Integer> q=new LinkedHashMap<>();
        for(Product p:cart){
            String key=p.category+"|"+p.name+"|"+String.format(Locale.US,"%.2f",p.price);
            q.put(key,q.containsKey(key)?q.get(key)+1:1);
        }
        return q;
    }

    Product productForKey(String key){
        String[] a=key.split("\\|",-1);
        for(Product p:cart){
            if(p.category.equals(a[0]) && p.name.equals(a[1])) return p;
        }
        return null;
    }

    void removeOne(Product p){
        if(p==null)return;
        for(int i=cart.size()-1;i>=0;i--){
            Product x=cart.get(i);
            if(x.category.equals(p.category) && x.name.equals(p.name) && x.price==p.price){
                cart.remove(i);
                break;
            }
        }
        render();
    }

    void render(){
        list.removeAllViews();
        LinkedHashMap<String,Integer> q=quantities();
        double sub=0;

        for(String key:q.keySet()){
            Product p=productForKey(key);
            if(p==null)continue;
            int qty=q.get(key);
            sub += p.price*qty;

            LinearLayout row=new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10),dp(4),dp(6),dp(4));
            row.setBackground(shape(Color.WHITE,10));

            TextView n=tv(qty+"x  "+p.name,14,Color.DKGRAY,true);
            TextView pr=tv(String.format(Locale.US,"R$ %.2f",p.price*qty).replace('.',','),14,purple,true);
            pr.setGravity(Gravity.CENTER);

            Button remove=button("−");
            remove.setTextSize(18);
            remove.setPadding(0,0,0,0);
            remove.setOnClickListener(v->removeOne(p));

            row.addView(n,new LinearLayout.LayoutParams(0,dp(52),1));
            row.addView(pr,new LinearLayout.LayoutParams(dp(100),dp(52)));
            row.addView(remove,new LinearLayout.LayoutParams(dp(48),dp(48)));

            list.addView(row,new LinearLayout.LayoutParams(-1,dp(58)));
            Space sp=new Space(this);
            list.addView(sp,new LinearLayout.LayoutParams(1,dp(5)));
        }

        double fee=num(delivery);
        total.setText(String.format(Locale.US,
                "SUBTOTAL: R$ %.2f\nTOTAL: R$ %.2f",sub,sub+fee).replace('.',','));
    }

    void clearAll(){
        cart.clear();
        customer.setText("");
        address.setText("");
        ref.setText("");
        obs.setText("");
        delivery.setText("");
        payment.setSelection(0);
        status.setSelection(0);
        render();
        Toast.makeText(this,"Comanda e campos limpos.",Toast.LENGTH_SHORT).show();
    }

    double num(EditText e){
        try{return Double.parseDouble(e.getText().toString().replace(",","."));}
        catch(Exception x){return 0;}
    }

    String fit(String s){
        s=s==null?"":s.replace("\r","").replace("\n"," ");
        if(s.length()>32)return s.substring(0,32);
        StringBuilder b=new StringBuilder(s);
        while(b.length()<32)b.append(' ');
        return b.toString();
    }

    String right(String label,double value){
        String val=String.format(Locale.US,"R$ %.2f",value).replace('.',',');
        int spaces=32-label.length()-val.length();
        if(spaces<1)spaces=1;
        return fit(label+repeat(' ',spaces)+val);
    }

    String repeat(char c,int n){
        StringBuilder b=new StringBuilder();
        for(int i=0;i<n;i++)b.append(c);
        return b.toString();
    }

    String itemLine(Product p,int qty){
        String q=qty+"x";
        String name=p.name==null?"":p.name.toUpperCase(Locale.ROOT);
        if(name.length()>19)name=name.substring(0,19);
        String val=String.format(Locale.US,"%.2f",p.price*qty).replace('.',',');
        int spaces=32-q.length()-2-name.length()-val.length();
        if(spaces<1)spaces=1;
        return fit(q+"  "+name+repeat(' ',spaces)+val);
    }

    String receipt(){
        Calendar now=Calendar.getInstance();
        String date=new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(now.getTime());
        String time=new SimpleDateFormat("HH:mm",Locale.getDefault()).format(now.getTime());
        int no=getPreferences(0).getInt("order",1);

        LinkedHashMap<String,Integer> q=quantities();
        double sub=0;
        for(String key:q.keySet()){
            Product p=productForKey(key);
            if(p!=null)sub+=p.price*q.get(key);
        }
        double fee=num(delivery), totalV=sub+fee;

        StringBuilder s=new StringBuilder();
        s.append("================================\n");
        s.append(fit("         MIGUEL LANCHES")+"\n");
        s.append(fit("   Hamburgueria e Pizzaria")+"\n");
        s.append("================================\n");
        s.append(fit("Data: "+date+"      Hora: "+time)+"\n");
        s.append(fit("Pedido: #"+String.format(Locale.US,"%03d",no))+"\n");
        s.append("--------------------------------\n");
        s.append(fit("QTD ITEM                 VALOR")+"\n");
        s.append("--------------------------------\n");

        for(String key:q.keySet()){
            Product p=productForKey(key);
            if(p!=null)s.append(itemLine(p,q.get(key))).append("\n");
        }

        s.append("--------------------------------\n");
        s.append(right("SUBTOTAL:",sub)+"\n");
        s.append(right("TAXA DE ENTREGA:",fee)+"\n");
        s.append("--------------------------------\n");
        s.append(right("TOTAL:",totalV)+"\n");
        s.append("--------------------------------\n");
        s.append(fit("FORMA DE PAGAMENTO: "+payment.getSelectedItem().toString())+"\n");
        s.append(fit("STATUS: "+status.getSelectedItem().toString())+"\n");
        s.append("--------------------------------\n");
        s.append(fit("CLIENTE: "+customer.getText().toString())+"\n");
        s.append(fit("ENDERECO: "+address.getText().toString())+"\n");
        s.append(fit("REF: "+ref.getText().toString())+"\n");
        s.append(fit("OBS: "+obs.getText().toString())+"\n");
        s.append("================================\n");
        s.append(fit("    Obrigado pela preferencia!")+"\n");
        s.append("================================\n");
        return s.toString();
    }

    void doPrint(){
        if(cart.isEmpty()){
            Toast.makeText(this,"Adicione pelo menos um produto.",Toast.LENGTH_SHORT).show();
            return;
        }
        BluetoothPrinter.print(this,receipt(),(ok,msg)->{
            Toast.makeText(this,msg,Toast.LENGTH_LONG).show();
            if(ok){
                int n=getPreferences(0).getInt("order",1);
                getPreferences(0).edit().putInt("order",n+1).apply();
            }
        });
    }
}
