# Miguel Lanches v10

- Botão separado FINALIZAR PEDIDO.
- Finalizar salva o cliente, imprime, limpa produtos e campos digitáveis.
- Após finalizar, abre WhatsApp com:
  "Vim aqui te dizer que *já estamos preparando* o seu pedido 🚀
   Tempo estimado é de 40 - 90 minutos!"
- Saiu para entrega:
  "Seu pedido já está a caminho 🛵!"
- Entregue:
  "Agradecemos a preferência e esperamos te reencontrar em breve 😃!"
  + link do Instagram informado pelo usuário.
